﻿INSERT INTO campanias.antecedente_familiar (codigo,atencion,tipo_afeccion_familiar,observacion,usr_create,time_create,usr_update,time_update) VALUES (
2,1,1,'Non-invasive placement of bone growth stimulator','postgres','2017-09-11 10:13:23.865','postgres','2017-09-11 10:13:23.865');
INSERT INTO campanias.antecedente_familiar (codigo,atencion,tipo_afeccion_familiar,observacion,usr_create,time_create,usr_update,time_update) VALUES (
3,1,2,'Removal of orbital implant','postgres','2017-09-11 10:13:27.578','postgres','2017-09-11 10:13:27.578');
INSERT INTO campanias.antecedente_familiar (codigo,atencion,tipo_afeccion_familiar,observacion,usr_create,time_create,usr_update,time_update) VALUES (
4,1,3,'Repair of endocardial cushion defect with prosthesis','postgres','2017-09-11 10:13:31.392','postgres','2017-09-11 10:13:31.392');
INSERT INTO campanias.antecedente_familiar (codigo,atencion,tipo_afeccion_familiar,observacion,usr_create,time_create,usr_update,time_update) VALUES (
5,1,4,'Incision of cornea','postgres','2017-09-11 10:13:31.392','postgres','2017-09-11 10:13:31.392');
INSERT INTO campanias.antecedente_familiar (codigo,atencion,tipo_afeccion_familiar,observacion,usr_create,time_create,usr_update,time_update) VALUES (
6,1,5,'Unilateral adrenalectomy','postgres','2017-09-11 10:13:31.392','postgres','2017-09-11 10:13:31.392');
INSERT INTO campanias.antecedente_familiar (codigo,atencion,tipo_afeccion_familiar,observacion,usr_create,time_create,usr_update,time_update) VALUES (
7,1,6,'Other operations on extraocular muscles and tendons','postgres','2017-09-11 10:13:31.392','postgres','2017-09-11 10:13:31.392');
INSERT INTO campanias.antecedente_familiar (codigo,atencion,tipo_afeccion_familiar,observacion,usr_create,time_create,usr_update,time_update) VALUES (
8,1001,1,'Alguna observacion','postgres','2017-09-12 09:25:19.525','postgres','2017-09-12 09:25:19.525');
