﻿INSERT INTO campanias.antecedente_personal (codigo,atencion,tipo_afeccion_personal,observacion,usr_create,time_create,usr_update,time_update) VALUES (
1,1,7,'Non-invasive placement of bone growth stimulator','postgres','2017-09-11 10:15:24.072','postgres','2017-09-11 10:15:24.072');
INSERT INTO campanias.antecedente_personal (codigo,atencion,tipo_afeccion_personal,observacion,usr_create,time_create,usr_update,time_update) VALUES (
2,1,8,'Removal of orbital implant','postgres','2017-09-11 10:15:24.072','postgres','2017-09-11 10:15:24.072');
INSERT INTO campanias.antecedente_personal (codigo,atencion,tipo_afeccion_personal,observacion,usr_create,time_create,usr_update,time_update) VALUES (
3,1,9,'Repair of endocardial cushion defect with prosthesis','postgres','2017-09-11 10:15:24.072','postgres','2017-09-11 10:15:24.072');
INSERT INTO campanias.antecedente_personal (codigo,atencion,tipo_afeccion_personal,observacion,usr_create,time_create,usr_update,time_update) VALUES (
4,1,10,'Incision of cornea','postgres','2017-09-11 10:15:24.072','postgres','2017-09-11 10:15:24.072');
INSERT INTO campanias.antecedente_personal (codigo,atencion,tipo_afeccion_personal,observacion,usr_create,time_create,usr_update,time_update) VALUES (
5,1,11,'Unilateral adrenalectomy','postgres','2017-09-11 10:15:24.072','postgres','2017-09-11 10:15:24.072');
INSERT INTO campanias.antecedente_personal (codigo,atencion,tipo_afeccion_personal,observacion,usr_create,time_create,usr_update,time_update) VALUES (
6,1,12,'Other operations on extraocular muscles and tendons','postgres','2017-09-11 10:15:24.072','postgres','2017-09-11 10:15:24.072');
INSERT INTO campanias.antecedente_personal (codigo,atencion,tipo_afeccion_personal,observacion,usr_create,time_create,usr_update,time_update) VALUES (
7,1001,3,'Observacion de antecedentes personal','postgres','2017-09-12 09:26:12.040','postgres','2017-09-12 09:26:12.040');
