﻿INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
1,'2005-05-03','Nondisplaced fracture of medial phalanx of unspecified lesser toe(s), initial encounter for open fracture',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
2,'2007-08-06','Displaced fracture of distal phalanx of left index finger, initial encounter for closed fracture',1,2,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
3,'2008-11-13','Unspecified dislocation of left index finger',1,2,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
4,'2012-06-30','Major laceration of left vertebral artery, initial encounter',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
5,'2012-06-02','Underdosing of other primarily systemic and hematological agents, sequela',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
6,'2015-11-01','Dislocation of C1/C2 cervical vertebrae, sequela',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
7,'2016-06-19','Other injury of extensor muscle, fascia and tendon of right little finger at forearm level, sequela',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
8,'2011-06-05','Other meniscus derangements, posterior horn of lateral meniscus, left knee',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
9,'2008-05-26','Unspecified pre-existing hypertension complicating the puerperium',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
10,'2005-12-04','Contusion of unspecified index finger without damage to nail, initial encounter',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
11,'2007-08-25','Other spondylosis with radiculopathy',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
12,'2014-01-30','Bus occupant (driver) (passenger) injured in unspecified traffic accident, initial encounter',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
13,'2005-06-11','Burn of first degree of single right finger (nail) except thumb, initial encounter',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
14,'2005-05-28','Unspecified open wound of vocal cord, initial encounter',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
15,'2006-09-22','Unspecified fracture of facial bones, initial encounter for open fracture',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
16,'2000-04-04','Diseases of the nervous system complicating pregnancy, first trimester',1,2,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
17,'2012-08-16','Chronic multifocal osteomyelitis, multiple sites',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
18,'2006-10-19','Corrosion of second degree of right scapular region, sequela',1,2,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
19,'2015-12-06','Displaced fracture of olecranon process with intraarticular extension of right ulna, subsequent encounter for closed fracture with delayed healing',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
20,'2016-07-13','Nondisplaced transcondylar fracture of right humerus, subsequent encounter for fracture with nonunion',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
21,'2011-02-21','Infection of amniotic sac and membranes, unspecified, third trimester, fetus 2',1,2,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
22,'2005-12-26','Stress fracture, unspecified shoulder, subsequent encounter for fracture with routine healing',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
23,'2007-10-28','Crushing injury of left thumb, initial encounter',1,2,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
24,'2003-04-14','Pathological fracture in neoplastic disease, right humerus, subsequent encounter for fracture with nonunion',1,3,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
INSERT INTO campanias.antecedente_siniestro (codigo,fecha,motivo,atencion,tipo_antecedente_siniestro,usr_create,time_create,usr_update,time_update) VALUES (
25,'2013-02-16','Other congenital malformations of aorta',1,1,'postgres','2017-09-11 10:27:20.899','postgres','2017-09-11 10:27:20.899');
