﻿INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
1,'Contusion of fallopian tube, unilateral, subsequent encounter','2000-01-20',151489,'03LS4DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
2,'Unspecified pedal cyclist injured in collision with other and unspecified motor vehicles in traffic accident','1993-07-27',151516,'0HBDXZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
3,'Nondisplaced fracture of medial phalanx of right little finger, subsequent encounter for fracture with delayed healing','1990-09-29',151526,'0KUL4JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
4,'Other superficial bite of throat','1992-02-19',151519,'067C4DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
5,'Other fractures of lower end of unspecified radius, subsequent encounter for closed fracture with nonunion','2006-02-08',151506,'02WY4DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
6,'Unspecified inflammatory spondylopathy, lumbar region','1995-01-24',151500,'047W066','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
7,'Separation of muscle (nontraumatic), unspecified forearm','1994-03-03',151520,'D911B7Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
8,'Pneumococcal arthritis, left hip','2008-02-11',151493,'0SGC0KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
9,'Sprain of interphalangeal joint of right middle finger, sequela','1999-07-23',151510,'0DU34KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
10,'Algoneurodystrophy, other site','2017-10-19',151530,'0NB24ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
11,'Unspecified superficial injury of left wrist, subsequent encounter','2009-01-29',151506,'09TP4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
12,'Nondisplaced fracture of shaft of third metacarpal bone, right hand','2004-04-02',151520,'0SPM03Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
13,'Infection and inflammatory reaction due to implanted testicular prosthesis, sequela','2007-03-22',151521,'0PWG44Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
14,'Pedestrian on foot injured in collision with railway train or railway vehicle, unspecified whether traffic or nontraffic accident, subsequent encounter','2014-09-23',151494,'0D920ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
15,'Toxic effect of venom of other snake, intentional self-harm, subsequent encounter','2018-03-18',151496,'09RE0JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
16,'Displaced fracture of lower epiphysis (separation) of left femur','2018-08-17',151517,'018R0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
17,'Nondisplaced avulsion fracture of left ilium, sequela','1999-04-03',151506,'0QPL4KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
18,'Unspecified fracture of shaft of right tibia, subsequent encounter for open fracture type I or II with routine healing','1996-01-22',151495,'0TUB4KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
19,'Food in other parts of respiratory tract causing other injury, sequela','2017-10-03',151498,'0TR38JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
20,'Nondisplaced comminuted fracture of shaft of right femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','2009-10-25',151512,'0WW903Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
21,'Exposure to smoke in uncontrolled fire in building or structure, initial encounter','1996-07-17',151517,'0UC70ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
22,'Infections of other parts of urinary tract in pregnancy, third trimester','2013-04-01',151516,'3E0U0GB','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
23,'Melanoma in situ of unspecified ear and external auricular canal','2000-11-09',151484,'BR15YZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
24,'Blister (nonthermal) of right elbow, initial encounter','2007-06-05',151499,'04LQ4DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
25,'Displaced fracture of medial phalanx of right lesser toe(s), initial encounter for open fracture','2004-12-20',151528,'0Q8D3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
26,'Strain of right Achilles tendon, initial encounter','1995-12-27',151498,'0JPV3XZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
27,'Poisoning by, adverse effect of and underdosing of electrolytic, caloric and water-balance agents','2014-01-30',151521,'0YJ5XZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
28,'Corrosion of second degree of multiple sites of shoulder and upper limb, except wrist and hand','2011-04-14',151489,'0KNL0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
29,'Other superficial bite of other specified part of neck, sequela','1996-05-26',151510,'06LH0CZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
30,'Insect bite (nonvenomous), left foot, initial encounter','2006-02-18',151518,'0RGA3K0','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
31,'Unspecified dislocation of left patella, initial encounter','1996-04-12',151509,'03714GZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
32,'Nondisplaced fracture of body of left talus, sequela','2015-08-09',151490,'0DHB33Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
33,'Mesothelioma of peritoneum','2009-12-03',151525,'05993ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
34,'Hemolytic transfusion reaction, unspecified incompatibility, unspecified as acute or delayed, initial encounter','2006-11-25',151529,'04760EZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
35,'Burn of first degree of unspecified hand, unspecified site','1995-08-03',151521,'03VU4DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
36,'Nondisplaced spiral fracture of shaft of left tibia, subsequent encounter for closed fracture with routine healing','1998-11-01',151487,'0LB','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
37,'Complete physeal arrest, left distal femur','2007-03-30',151489,'0SPB35Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
38,'Unspecified male sexual dysfunction','2013-10-05',151486,'0QWN4KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
39,'Dislocation of C2/C3 cervical vertebrae, sequela','1990-08-24',151524,'0WHM03Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
40,'Low-tension glaucoma, unspecified eye, moderate stage','1991-02-19',151490,'07N94ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
41,'Poisoning by anthelminthics, intentional self-harm, sequela','2007-06-06',151509,'03CN0Z6','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
42,'Myositis ossificans progressiva, shoulder','2002-01-23',151533,'0TWD3LZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
43,'Unspecified fracture of unspecified calcaneus','1990-11-02',151512,'047N4D1','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
44,'Unspecified occupant of pick-up truck or van injured in collision with unspecified motor vehicles in nontraffic accident, initial encounter','2003-08-07',151503,'0J850ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
45,'Other specified injury of unspecified renal vein','1996-01-22',151506,'0RUU0JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
46,'Severely displaced Zone II fracture of sacrum, subsequent encounter for fracture with nonunion','2014-03-19',151516,'0D198ZA','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
47,'Unspecified fracture of head of left femur, subsequent encounter for closed fracture with nonunion','1998-01-24',151506,'0QUC0KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
48,'Traumatic hemorrhage of left cerebrum with loss of consciousness of unspecified duration','1995-03-05',151488,'02QJ4ZG','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
49,'Salter-Harris Type III physeal fracture of upper end of humerus, right arm, subsequent encounter for fracture with routine healing','1993-04-08',151492,'0KUB07Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
50,'Other disturbances of smell and taste','2012-03-11',151509,'05HC03Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
51,'Poisoning by macrolides, assault, initial encounter','1999-04-20',151491,'04764E6','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
52,'Laceration of lesser saphenous vein at lower leg level, right leg, subsequent encounter','1995-01-17',151484,'0SW508Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
53,'Central dislocation of left hip, subsequent encounter','2009-12-19',151527,'0SC53ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
54,'Displaced oblique fracture of shaft of right fibula, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with malunion','1990-06-15',151491,'03B40ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
55,'Nonexudative age-related macular degeneration, right eye, early dry stage','2004-06-22',151509,'0RUE07Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
56,'Poisoning by dental drugs, topically applied, assault, initial encounter','2013-12-11',151532,'0HD0XZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
57,'Varicose veins of unspecified lower extremity with ulcer other part of lower leg','2017-07-26',151513,'047E0D6','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
58,'Term delivery with preterm labor, second trimester, fetus 5','2003-03-05',151527,'04H103Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
59,'Fall on board merchant ship','1998-05-24',151518,'07950ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
60,'Contusion and laceration of right cerebrum with loss of consciousness of 30 minutes or less, subsequent encounter','2012-01-09',151486,'02US0JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
61,'Poisoning by tetracyclic antidepressants, assault','1991-04-17',151490,'05DD3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
62,'Strain of muscle(s) and tendon(s) of peroneal muscle group at lower leg level, left leg, subsequent encounter','1999-03-08',151514,'0QW144Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
63,'Ocular laceration and rupture with prolapse or loss of intraocular tissue, right eye','1995-01-15',151511,'2W5FX5Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
64,'Displacement of muscle and tendon graft, initial encounter','2012-07-21',151519,'3E0C3NZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
65,'Other disorders of propionate metabolism','1991-10-07',151491,'0Y0K0KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
66,'Puncture wound without foreign body of unspecified great toe with damage to nail, sequela','2004-04-08',151501,'0PWF35Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
67,'Other displaced fracture of fifth cervical vertebra, subsequent encounter for fracture with routine healing','2010-05-27',151501,'04LQ0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
68,'Unspecified superficial injury of oral cavity, sequela','1990-08-02',151506,'0RPD37Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
69,'Other disorders of white blood cells','2014-04-23',151517,'0TP943Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
70,'Displaced oblique fracture of shaft of right femur, subsequent encounter for open fracture type I or II with routine healing','1995-06-24',151492,'099M30Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
71,'Dislocation of tarsometatarsal joint of unspecified foot, initial encounter','2019-02-23',151526,'0PPTX5Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
72,'Nondisplaced fracture of proximal phalanx of right great toe, initial encounter for open fracture','2002-03-12',151484,'00UQ07Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
73,'Unspecified injury to unspecified level of lumbar spinal cord, sequela','2000-06-20',151525,'0CRT8JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
74,'Acute Eustachian salpingitis, left ear','2004-12-03',151490,'0GBG0ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
75,'Nondisplaced fracture of neck of first metacarpal bone, left hand, initial encounter for closed fracture','2017-05-27',151498,'2W5DX7Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
76,'Nondisplaced oblique fracture of shaft of unspecified femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with malunion','1994-10-19',151494,'0S9D30Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
77,'Poisoning by oxytocic drugs, undetermined','1998-05-05',151500,'B90D0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
78,'Other specified injury of deep palmar arch of right hand, sequela','2015-11-27',151525,'065T0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
79,'Puncture wound without foreign body of unspecified shoulder, sequela','2005-02-27',151488,'0NWW4KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
80,'Toxic effect of venom of gila monster','2012-12-27',151533,'2W5AX1Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
81,'Encounter for antineoplastic chemotherapy','2012-05-05',151519,'06HN4DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
82,'Nondisplaced Type II dens fracture, initial encounter for open fracture','2015-03-27',151530,'D0006ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
83,'Laceration with foreign body of left cheek and temporomandibular area, sequela','2006-05-10',151496,'BP16ZZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
84,'Contusion of middle finger with damage to nail','1996-03-14',151504,'0Y9J4ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
85,'Unspecified injury','2018-01-20',151520,'D01697Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
86,'Poisoning by diagnostic agents, intentional self-harm, sequela','2010-03-18',151500,'00SX0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
87,'Toxic effect of lacrimogenic gas, intentional self-harm, initial encounter','2013-10-30',151521,'03C04Z6','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
88,'Reiter''s disease, unspecified hand','2018-02-28',151496,'0UU40JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
89,'Nondisplaced transverse fracture of shaft of left femur, subsequent encounter for closed fracture with delayed healing','1995-07-04',151521,'0LSK0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
90,'Unspecified superficial injury of lower back and pelvis, subsequent encounter','2012-04-04',151510,'F07D3FZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
91,'Other rupture of muscle (nontraumatic), unspecified ankle and foot','2003-01-20',151514,'BQ2GYZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
92,'Subluxation of unspecified interphalangeal joint of unspecified thumb','2007-08-16',151501,'0SP03JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
93,'Vesicovaginal fistula','1992-02-28',151492,'0DFK3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
94,'Toxic effect of carbon monoxide','2006-08-08',151486,'047A4FZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
95,'War operations involving explosion of improvised explosive device [IED], civilian, subsequent encounter','1998-04-06',151502,'0RWF07Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
96,'Stable burst fracture of fourth lumbar vertebra, subsequent encounter for fracture with nonunion','1990-06-14',151499,'03L74ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
97,'Lymphangitis','2005-06-17',151533,'0JPV3JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
98,'Unspecified fracture of unspecified thoracic vertebra, initial encounter for open fracture','1998-04-03',151513,'0N9240Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
99,'Superficial foreign body of unspecified front wall of thorax, subsequent encounter','2003-02-12',151533,'DV2','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
100,'Toxic effect of contact with sea anemone, undetermined, subsequent encounter','2014-06-01',151495,'0SW00AZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
101,'Iron deficiency anemia','2009-06-23',151509,'0VSG0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
102,'Crimean-Congo hemorrhagic fever','1991-04-11',151491,'041C4JQ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
103,'Open wound of anus','1991-12-26',151508,'BQ04ZZ1','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
104,'Other mechanical complication of other nervous system device, implant or graft','2006-05-04',151490,'BV0','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
105,'Other physeal fracture of lower end of ulna, unspecified arm, subsequent encounter for fracture with delayed healing','2016-08-04',151507,'3E0533Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
106,'Bitten by macaw','1999-07-14',151514,'DB086ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
107,'Open bite of right wrist, initial encounter','1994-12-11',151491,'0DRV07Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
108,'Pathological fracture, left shoulder, subsequent encounter for fracture with malunion','1991-03-18',151487,'0NUN37Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
109,'Osteophyte, unspecified joint','1999-12-24',151496,'B419110','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
110,'Displaced comminuted supracondylar fracture without intercondylar fracture of unspecified humerus, initial encounter for open fracture','2003-02-28',151507,'0D1M8KM','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
111,'Unspecified injury of thoracic aorta, sequela','2017-04-08',151514,'0W934ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
112,'Other contact with other nonvenomous marine animals, initial encounter','1995-09-08',151513,'06LH3CZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
113,'Infection and inflammatory reaction due to internal fixation device of left ulna, sequela','2008-01-21',151495,'0CRT7JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
114,'Nondisplaced fracture of first metatarsal bone, left foot, subsequent encounter for fracture with delayed healing','2015-04-09',151488,'F14Z3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
115,'Chronic intestinal amebiasis','2017-10-01',151529,'0BL97ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
116,'Unspecified fracture of shaft of right ulna, subsequent encounter for closed fracture with nonunion','1991-01-22',151512,'0WW10YZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
117,'Breakdown (mechanical) of internal fixation device of bones of hand and fingers','2011-01-26',151502,'061F0KY','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
118,'Frostbite with tissue necrosis of left foot, sequela','2011-07-08',151505,'0FND7ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
119,'Traumatic rupture of unspecified radiocarpal ligament','2013-08-30',151485,'HZ31ZZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
120,'Passenger in three-wheeled motor vehicle injured in collision with other nonmotor vehicle in nontraffic accident, sequela','2005-03-18',151492,'047W47Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
121,'Military operations involving rubber bullets','2017-07-03',151512,'0DLQ8DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
122,'Rheumatoid polyneuropathy with rheumatoid arthritis of unspecified site','2002-11-08',151532,'069Y30Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
123,'Uncongenial work environment','1991-09-30',151521,'0FUF47Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
124,'Other specified disorders of tendon, left elbow','2014-09-24',151513,'039J3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
125,'Other viral diseases complicating the puerperium','2017-01-18',151533,'0CR','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
126,'Twin liveborn infant, delivered vaginally','2017-02-01',151500,'02HX40Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
127,'Nondisplaced oblique fracture of shaft of left fibula, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with routine healing','2019-10-19',151510,'0VHS33Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
128,'Poisoning by other laxatives, accidental (unintentional)','1997-08-23',151492,'0W003ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
129,'Other vomiting of newborn','1991-08-04',151495,'0BQ93ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
130,'Nondisplaced fracture of anterior process of right calcaneus','1991-01-30',151492,'041F0KH','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
131,'Drowning and submersion due to being washed overboard from water-skis, sequela','2013-01-11',151486,'099W3ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
132,'Stress fracture, right tibia, initial encounter for fracture','1990-12-28',151505,'0WPF0KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
133,'Acute embolism and thrombosis of superior vena cava','1994-10-04',151533,'0UF70ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
134,'Partial traumatic amputation at level between knee and ankle, right lower leg, initial encounter','1990-03-26',151491,'0DQ44ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
135,'Strain of muscle and tendon of long flexor muscle of toe at ankle and foot level, left foot, initial encounter','2009-12-29',151500,'09CP3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
136,'Sick-euthyroid syndrome','2009-11-06',151521,'D91199Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
137,'Exhaustion due to exposure, initial encounter','2017-09-25',151502,'0LRV07Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
138,'Gastric contents in respiratory tract, part unspecified causing other injury, initial encounter','1995-03-02',151525,'037B0F6','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
139,'Genetic susceptibility to other malignant neoplasm','2011-11-13',151486,'0PP004Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
140,'Toxic effect of carbon monoxide from unspecified source, accidental (unintentional), subsequent encounter','1993-06-06',151503,'0QQMXZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
141,'Other mechanical complication of surgically created arteriovenous shunt, subsequent encounter','1999-09-09',151524,'0VBL3ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
142,'Contact with sword or dagger, undetermined intent','2006-05-12',151510,'0J970ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
143,'Atherosclerosis of nonautologous biological bypass graft(s) of other extremity with ulceration','2011-06-03',151518,'07PK4DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
144,'Superficial frostbite of finger(s)','2004-06-20',151495,'0RWF34Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
145,'Displaced trimalleolar fracture of unspecified lower leg, initial encounter for open fracture type IIIA, IIIB, or IIIC','1998-01-02',151506,'041C0Z9','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
146,'Carcinoma in situ of vagina','2008-10-28',151522,'D0Y6KZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
147,'Underdosing of antifungal antibiotics, systemically used, subsequent encounter','1992-09-07',151524,'0YJ64ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
148,'Osteochondritis dissecans of wrist','1996-03-16',151503,'BT30ZZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
149,'Other venous complications following complete or unspecified spontaneous abortion','2000-04-30',151528,'037B0FZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
150,'Nondisplaced fracture of sternal end of right clavicle, sequela','2000-09-13',151512,'0RWD0KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
151,'Adverse effect of antithyroid drugs','1991-12-27',151529,'049E4ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
152,'Nondisplaced fracture of lateral condyle of left femur, initial encounter for closed fracture','2017-11-15',151495,'0SCF3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
153,'Achilles tendinitis','1999-03-27',151502,'3E0J3HZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
154,'Unspecified intracapsular fracture of unspecified femur, initial encounter for open fracture type I or II','2015-07-31',151517,'HZ5CZZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
155,'Pleural plaque','1990-04-27',151497,'0GC43ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
156,'Traumatic amputation of hand at wrist level','1996-01-08',151487,'0BBG8ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
157,'Synovial hypertrophy, not elsewhere classified, forearm','2005-03-01',151530,'0BC87ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
158,'Encounter for supervision of normal pregnancy','1998-02-26',151531,'CW2BYZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
159,'Nondisplaced fracture of third metatarsal bone, right foot','2013-08-11',151520,'10Q','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
160,'Toxic effect of tetrachloroethylene, undetermined','1993-02-20',151531,'30277H1','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
161,'Unspecified superficial injury of unspecified hip, sequela','1996-10-02',151499,'039T30Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
162,'Hidradenitis suppurativa','1990-01-29',151508,'0WHM41Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
163,'Chronic multifocal osteomyelitis, unspecified femur','2005-08-31',151498,'0F980ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
164,'Encounter for adjustment and management of other cardiac device','1991-07-17',151488,'009Q0ZX','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
165,'Fall from other furniture, sequela','2015-01-01',151525,'B4070ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
166,'Displaced segmental fracture of shaft of unspecified tibia, subsequent encounter for closed fracture with malunion','1992-10-31',151498,'BQ210ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
167,'Other specified injury of left quadriceps muscle, fascia and tendon','2006-06-01',151525,'0QRH0KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
168,'Person on outside of pick-up truck or van injured in noncollision transport accident in nontraffic accident, initial encounter','1999-03-18',151487,'0HPQXKZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
169,'Continuing pregnancy after elective fetal reduction of one fetus or more','1998-08-12',151530,'0QP84JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
170,'Unspecified open wound of left middle finger without damage to nail, sequela','1992-09-17',151522,'0SP2X3Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
171,'War operations involving destruction of aircraft due to collision with other aircraft, military personnel, initial encounter','1990-10-17',151514,'0SBF0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
172,'Displaced trimalleolar fracture of right lower leg, subsequent encounter for closed fracture with malunion','2013-02-09',151516,'0DB33ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
173,'Person injured while boarding or alighting from streetcar, initial encounter','2005-02-08',151531,'0L5V4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
174,'Hydroxyapatite deposition disease, hip','2005-04-25',151493,'0UQ77ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
175,'Term delivery with preterm labor, third trimester, fetus 1','2000-10-10',151531,'0RNR0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
176,'External constriction, left lower leg','2005-12-04',151498,'DF013ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
177,'Retrobulbar neuritis','2002-12-27',151486,'027H0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
178,'Traumatic hemorrhage of right cerebrum with loss of consciousness of 6 hours to 24 hours, sequela','2019-09-18',151496,'DD015ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
179,'Other embolism in the puerperium','2010-09-14',151484,'037H376','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
180,'Corrosion of first degree of right knee, subsequent encounter','2003-09-25',151498,'0QS83BZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
181,'Ophthalmia nodosa, left eye','2001-04-11',151507,'BF37ZZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
182,'Displaced bicondylar fracture of right tibia, initial encounter for open fracture type I or II','2008-06-05',151531,'03150A5','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
183,'Displaced spiral fracture of shaft of radius, unspecified arm, initial encounter for open fracture type IIIA, IIIB, or IIIC','1995-01-16',151485,'0QH90BZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
184,'Military operations involving destruction of aircraft due to collision with other aircraft, military personnel, subsequent encounter','2005-02-07',151486,'0D1B8JP','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
185,'Other juvenile osteochondrosis, right upper limb','2011-05-22',151526,'0TVD7DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
186,'Unspecified maternal infectious and parasitic disease complicating pregnancy, childbirth and the puerperium','2006-09-09',151518,'F02BGZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
187,'Spinal and epidural anesthesia-induced headache during labor and delivery','2002-03-10',151519,'0WW20JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
188,'Nondisplaced oblique fracture of shaft of humerus, left arm, sequela','1993-06-10',151484,'00C84ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
189,'Fuchs'' heterochromic cyclitis, bilateral','1991-09-10',151511,'0SJP4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
190,'Recurrent oral aphthae','1994-08-24',151485,'0T134J6','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
191,'Corrosion of unspecified degree of right ear [any part, except ear drum]','1994-08-13',151521,'0DQP4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
192,'Nondisplaced fracture of posterior column [ilioischial] of left acetabulum, initial encounter for closed fracture','1997-05-19',151525,'0H0V37Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
193,'Cocaine use, unspecified with cocaine-induced psychotic disorder with delusions','2011-04-16',151502,'0T130J3','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
194,'Struck by other fish, subsequent encounter','2000-03-13',151505,'09Q43ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
195,'Other complications of foreign body accidentally left in body following other procedure, initial encounter','1997-08-28',151499,'F00ZV2Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
196,'Unspecified injury of muscle(s) and tendon(s) of the rotator cuff of right shoulder','2012-08-16',151487,'D9199BZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
197,'Unspecified sprain of unspecified finger','1997-11-30',151508,'0UB50ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
198,'Coloboma of optic disc, right eye','1998-05-06',151530,'0N9L0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
199,'Choroidal rupture, right eye','1998-10-13',151497,'10Q04YL','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
200,'Total retinal detachment, unspecified eye','2015-04-21',151504,'B52G00Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
201,'Vascular anomalies of unspecified eye, unspecified eyelid','2008-04-22',151510,'0PCP4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
202,'Non-pressure chronic ulcer of left heel and midfoot with unspecified severity','2015-03-14',151503,'05QP0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
203,'Stiffness of unspecified shoulder, not elsewhere classified','2011-01-12',151498,'0UN78ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
204,'Wedge compression fracture of first thoracic vertebra, subsequent encounter for fracture with routine healing','2012-01-01',151492,'0PT70ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
205,'Other sprain of unspecified foot, sequela','2013-11-08',151511,'0T9800Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
206,'Laceration of liver, unspecified degree','2015-01-29',151517,'04N34ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
207,'Crushing injury of larynx and trachea','2005-05-07',151525,'0QU90KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
208,'Unspecified injury of other blood vessels at abdomen, lower back and pelvis level, sequela','2014-10-02',151513,'009Y4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
209,'Other specified injury of other blood vessels of thorax, right side','2019-03-25',151520,'01N03ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
210,'Minor laceration of greater saphenous vein at hip and thigh level, left leg','2012-12-16',151484,'F07L6DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
211,'Other contact with parrot, sequela','2009-06-25',151512,'0DUF0JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
212,'Displaced fracture of lateral malleolus of left fibula, initial encounter for closed fracture','2007-01-15',151510,'02734DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
213,'Underdosing of keratolytics, keratoplastics, and other hair treatment drugs and preparations, subsequent encounter','2009-01-01',151518,'037L0D6','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
214,'Displaced fracture of medial condyle of unspecified humerus, subsequent encounter for fracture with routine healing','1990-05-12',151503,'0L803ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
215,'Pedestrian on skateboard injured in collision with heavy transport vehicle or bus, unspecified whether traffic or nontraffic accident','1994-08-22',151488,'0CPS3JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
216,'Displaced oblique fracture of shaft of left femur','1999-06-26',151499,'0NUJ3JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
217,'Abnormal level of other drugs, medicaments and biological substances in specimens from female genital organs','2002-05-24',151518,'0FV63ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
218,'Jumping or diving into natural body of water striking bottom causing other injury, initial encounter','1990-07-02',151490,'0G9440Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
219,'Infection of amniotic sac and membranes, unspecified, unspecified trimester, fetus 5','2010-04-07',151528,'BT4','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
220,'Pedal cycle driver injured in collision with heavy transport vehicle or bus in traffic accident','1993-09-08',151508,'061S0KY','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
221,'Tympanosclerosis, unspecified ear','2001-10-06',151500,'0PHD46Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
222,'Traumatic subarachnoid hemorrhage with loss of consciousness of 31 minutes to 59 minutes, initial encounter','1990-11-08',151516,'3E0N70M','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
223,'Subluxation of unspecified acromioclavicular joint, sequela','2008-01-27',151485,'0TD04ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
224,'Adverse effect of phenothiazine antipsychotics and neuroleptics, initial encounter','1991-08-19',151489,'0PQK0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
225,'Aneurysm of unspecified site','1990-02-23',151496,'0SRE039','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
226,'Toxic effect of contact with Portugese Man-o-war, assault, subsequent encounter','2003-11-09',151521,'0D593ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
227,'Malignant neoplasm of fallopian tube','1991-03-04',151525,'0SUP3KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
228,'Toxic effect of arsenic and its compounds, undetermined, initial encounter','2011-03-20',151514,'BT33ZZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
229,'Myoadenylate deaminase deficiency','1994-05-15',151501,'BP3','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
230,'Salter-Harris Type III physeal fracture of lower end of ulna, right arm, sequela','2008-05-18',151487,'0QSK45Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
231,'Open bite of lower back and pelvis with penetration into retroperitoneum, initial encounter','1994-12-04',151497,'0D158ZB','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
232,'(Induced) termination of pregnancy with other complications','2002-12-07',151504,'061N0AY','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
233,'LeFort III fracture, subsequent encounter for fracture with nonunion','1996-03-19',151495,'049H0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
234,'Laceration without foreign body of left ring finger without damage to nail, subsequent encounter','2017-02-17',151514,'05R847Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
235,'Chronic periodontitis','1997-12-10',151507,'04560ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
236,'Blister (nonthermal) of upper arm','2014-04-14',151522,'0TVD7DZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
237,'Traumatic cerebral edema with loss of consciousness of any duration with death due to other cause prior to regaining consciousness, subsequent encounter','1996-09-29',151498,'30233X0','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
238,'Fracture of fifth metatarsal bone','1991-04-07',151508,'0FC84ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
239,'Unspecified subluxation of left shoulder joint','2019-07-14',151484,'0LQH0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
240,'Hit or struck by falling object due to accident to (nonpowered) inflatable craft, subsequent encounter','2004-06-03',151524,'01X84Z8','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
241,'Strain of intrinsic muscle, fascia and tendon of right index finger at wrist and hand level, subsequent encounter','2000-03-27',151529,'0Y6T0Z3','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
242,'Other fracture of lower end of left ulna, subsequent encounter for closed fracture with nonunion','1992-06-06',151515,'05140JY','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
243,'Nondisplaced comminuted fracture of shaft of right tibia, subsequent encounter for open fracture type I or II with malunion','1998-10-05',151490,'03LU4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
244,'Accidental malfunction of other gas, air or spring-operated gun, subsequent encounter','1996-12-25',151489,'02R608Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
245,'Vascular parkinsonism','1997-01-04',151494,'0U7C4ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
246,'Toxic effect of strychnine and its salts, assault, initial encounter','2011-04-27',151532,'B31B0ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
247,'Corrosion of second degree of unspecified multiple fingers (nail), including thumb, subsequent encounter','2012-12-20',151533,'0D154ZA','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
248,'Unstable burst fracture of T5-T6 vertebra','1993-01-30',151527,'0DLK8ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
249,'Nondisplaced segmental fracture of shaft of humerus, unspecified arm, initial encounter for closed fracture','2015-09-19',151522,'BF250ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
250,'Toxic effect of unspecified noxious substance eaten as food, undetermined, initial encounter','1993-01-16',151507,'0JNF3ZZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
251,'Oligohydramnios, first trimester, not applicable or unspecified','2013-01-13',151503,'03RG07Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
252,'Poisoning by, adverse effect of and underdosing of other synthetic narcotics','1994-10-12',151484,'0UP833Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
253,'Displaced fracture of medial condyle of unspecified femur, subsequent encounter for open fracture type I or II with nonunion','1995-02-08',151518,'2W37X2Z','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
254,'Explosion on board other powered watercraft, sequela','1994-08-10',151532,'03WY4KZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
255,'Kaschin-Beck disease, unspecified hip','2006-12-09',151516,'0XUD0JZ','postgres','2017-09-11 10:02:43.268','postgres','2017-09-11 10:02:43.268');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
256,'Displaced fracture of body of unspecified talus, initial encounter for open fracture','1994-12-13',151528,'0TWD8DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
257,'Hydroxyapatite deposition disease, wrist','2013-02-04',151496,'0U5G8ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
258,'Cannabis use, unspecified with psychotic disorder with delusions','2013-06-05',151498,'0L534ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
259,'Nondisplaced fracture of distal phalanx of right ring finger','2005-12-07',151499,'0RWHX3Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
260,'Skin donor','2002-01-08',151527,'0SC40ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
261,'Chlamydial vulvovaginitis','1997-10-16',151523,'0NW0X7Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
262,'Mumps','2009-02-15',151512,'06LG3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
263,'Sprain of left acromioclavicular joint, initial encounter','2012-02-15',151520,'049140Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
264,'Sudden idiopathic hearing loss','2002-08-12',151532,'0DUM4JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
265,'Unspecified physeal fracture of upper end of radius, unspecified arm, subsequent encounter for fracture with malunion','2015-01-22',151509,'037Y4E6','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
266,'Nondisplaced fracture of posterior column [ilioischial] of unspecified acetabulum, subsequent encounter for fracture with nonunion','2007-04-30',151522,'0FF57ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
267,'Military operations involving biological weapons, military personnel, subsequent encounter','2010-12-25',151523,'B93DZZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
268,'Fracture of thoracic vertebra','2005-02-03',151501,'009000Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
269,'Anorexia nervosa, unspecified','1993-08-19',151485,'02VV0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
270,'Pathological fracture, unspecified shoulder, subsequent encounter for fracture with routine healing','2006-03-25',151489,'0WJ04ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
271,'Foreign body in ear, unspecified ear, sequela','2014-09-09',151491,'0QSN45Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
272,'Exposure to other specified smoke, fire and flames, initial encounter','2003-10-05',151533,'0WW8X7Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
273,'Accidental puncture and laceration of a respiratory system organ or structure during a procedure','1996-06-01',151533,'0QH135Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
274,'Corrosion of third degree of right thigh','2019-06-21',151494,'0RHW33Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
275,'Strain of muscle(s) and tendon(s) of anterior muscle group at lower leg level, left leg','2006-09-13',151495,'0DNB0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
276,'Nondisplaced fracture of proximal phalanx of right little finger, subsequent encounter for fracture with delayed healing','2014-07-26',151492,'0RBS3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
277,'Corrosion of first degree of multiple sites of unspecified lower limb, except ankle and foot','2018-02-08',151525,'0X064KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
278,'Disorder of amniotic fluid and membranes, unspecified, first trimester, not applicable or unspecified','1991-11-27',151491,'0BW180Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
279,'Other trisomies and partial trisomies of the autosomes, not elsewhere classified','1992-03-02',151508,'04704ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
280,'Unspecified injury of other blood vessels at hip and thigh level, unspecified leg, sequela','2017-06-30',151484,'0FH202Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
281,'Benign neoplasm of left retina','2019-06-13',151496,'0DVG0DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
282,'Laceration of other blood vessels at lower leg level, right leg, initial encounter','2003-03-07',151513,'0DPU01Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
283,'Burn of unspecified degree of multiple sites of unspecified wrist and hand','2006-11-27',151497,'0SGQ47Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
284,'Other contact with and (suspected) exposures hazardous to health','2003-02-12',151487,'0SWFX5Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
285,'Benign neoplasm of connective and other soft tissue of pelvis','1994-09-22',151530,'0TRB0KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
286,'Unspecified injury of intrinsic muscle and tendon at ankle and foot level, left foot, sequela','2017-07-06',151516,'0Y0H3JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
287,'Underdosing of hydantoin derivatives, sequela','2011-04-23',151505,'0C9V8ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
288,'Contusion of eyeball and orbital tissues, left eye, initial encounter','1998-11-17',151490,'0BBD3ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
289,'Passenger in three-wheeled motor vehicle injured in collision with other nonmotor vehicle in nontraffic accident','1994-08-24',151517,'04HA03Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
290,'Allergic contact dermatitis, unspecified cause','2004-01-02',151489,'079K0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
291,'Extravasation of vesicant antineoplastic chemotherapy, initial encounter','2014-01-02',151513,'F06ZBPZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
292,'Poisoning by caffeine, intentional self-harm, subsequent encounter','2014-10-05',151533,'0DRW47Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
293,'Poisoning by cocaine, assault, subsequent encounter','1999-08-22',151496,'30253Q0','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
294,'Drowning and submersion due to falling or jumping from crushed passenger ship, sequela','1992-03-11',151507,'CW10YZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
295,'Unstable burst fracture of T7-T8 vertebra, initial encounter for closed fracture','2018-10-28',151521,'BQ1LZZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
296,'Unspecified focal traumatic brain injury with loss of consciousness greater than 24 hours with return to pre-existing conscious level','2001-10-08',151529,'00XN4ZM','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
297,'Nondisplaced fracture of lesser tuberosity of unspecified humerus, subsequent encounter for fracture with malunion','2010-09-24',151512,'03U107Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
298,'Pathological fracture, left foot, initial encounter for fracture','2006-11-24',151484,'0XBB0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
299,'Hemorrhage, not elsewhere classified','1997-10-20',151533,'05LV4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
300,'Alopecia universalis','1998-08-21',151520,'0PBJ0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
301,'Other chronic hematogenous osteomyelitis, left humerus','1998-10-27',151503,'0JHM3HZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
302,'Displaced intertrochanteric fracture of right femur, sequela','2005-01-08',151524,'0F9D4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
303,'Partial traumatic transphalangeal amputation of left middle finger, subsequent encounter','1997-11-21',151494,'0NBH0ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
304,'Underdosing of other antidysrhythmic drugs','2016-09-24',151498,'BT1DYZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
305,'Other specified disorders of bone, upper arm','2018-02-15',151526,'2W06XYZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
306,'Other specified type of carcinoma in situ of breast','2012-05-15',151498,'0MB40ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
307,'Unspecified injury of dorsal artery of foot','2000-01-12',151504,'00583ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
308,'Displacement of ventricular intracranial (communicating) shunt, sequela','1994-08-24',151485,'0W044ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
309,'Burn of ear drum','2003-03-14',151511,'0D9P8ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
310,'Other Rh incompatibility reaction due to transfusion of blood or blood products, sequela','1997-10-30',151490,'BN17YZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
311,'Passenger on bus injured in collision with car, pick-up truck or van in nontraffic accident, sequela','1994-07-07',151518,'01B24ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
312,'Laceration of unspecified blood vessel at abdomen, lower back and pelvis level','2011-01-04',151504,'0UNKXZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
313,'Poisoning by vitamins, intentional self-harm, sequela','1993-09-04',151491,'0SG937Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
314,'Laceration without foreign body of abdominal wall, left upper quadrant with penetration into peritoneal cavity, sequela','2008-06-19',151497,'04S53ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
315,'Intervertebral disc disorders with radiculopathy, thoracolumbar region','1993-10-13',151523,'0D917ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
316,'Legal intervention involving other gas, bystander injured, subsequent encounter','1998-10-11',151522,'DB27DZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
317,'Abrasion of unspecified external genital organs, male','1999-12-07',151514,'049P3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
318,'Psychophysiologic insomnia','1997-12-24',151521,'C75DYZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
319,'Encounter for pregnancy test and childbirth and childcare instruction','2001-06-23',151505,'B93','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
320,'Other injury of extensor muscle, fascia and tendon of right middle finger at forearm level, initial encounter','2012-03-08',151517,'0WWNXJZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
321,'Maternal care for other known or suspected poor fetal growth, third trimester, fetus 4','2017-10-11',151523,'0N5J0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
322,'Other osteonecrosis of right carpus','1990-01-25',151489,'09BK0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
323,'Legal intervention involving other explosives, bystander injured, subsequent encounter','2015-12-14',151517,'0DH542Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
324,'Other hypertrophic osteoarthropathy, right ankle and foot','1994-02-08',151524,'0CR13KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
325,'Partial traumatic amputation of unspecified ear, sequela','1992-11-27',151503,'0SWBX4Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
326,'Other specified diseases of gallbladder','1994-09-14',151529,'0T180JC','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
327,'Other malformation of placenta, second trimester','2017-03-29',151531,'0F150D4','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
328,'Preterm labor second trimester with preterm delivery second trimester, not applicable or unspecified','2006-01-19',151528,'0PS40ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
329,'Occupant of animal-drawn vehicle injured by fall from or being thrown from animal-drawn vehicle in noncollision accident','2011-01-22',151486,'0WQ83ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
330,'Acute oophoritis','2004-01-16',151521,'0CC50ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
331,'Burn of unspecified degree of multiple sites of unspecified ankle and foot, initial encounter','2006-04-26',151486,'0NSH04Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
332,'Corrosion of second degree of unspecified thigh, sequela','1997-02-25',151492,'2W4TX5Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
333,'Sprain of other specified parts of right knee','2017-07-07',151530,'0D7A3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
334,'Poisoning by unspecified primarily systemic and hematological agent, intentional self-harm, subsequent encounter','2013-10-13',151532,'07DR0ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
335,'Strain of long flexor muscle, fascia and tendon of left thumb at wrist and hand level, initial encounter','2007-07-12',151523,'0Q9L0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
336,'Intentional self-harm by blunt object, subsequent encounter','2009-11-23',151506,'03LY3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
337,'Contusion, laceration, and hemorrhage of cerebellum with loss of consciousness of any duration with death due to brain injury prior to regaining consciousness, sequela','1990-10-20',151486,'0RWS35Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
338,'Nondisplaced transverse fracture of unspecified patella, subsequent encounter for closed fracture with routine healing','1996-06-16',151525,'B313010','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
339,'Adverse effect of local astringents and local detergents, subsequent encounter','2009-01-12',151516,'0DSN8ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
340,'Breakdown (mechanical) of artificial skin graft and decellularized allodermis, sequela','1993-12-16',151495,'0F764DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
341,'Unspecified car occupant injured in collision with fixed or stationary object in nontraffic accident, sequela','1997-07-19',151485,'07LB3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
342,'Pigmentary glaucoma, right eye','2003-12-17',151486,'3E0M3GC','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
343,'Salter-Harris Type II physeal fracture of lower end of ulna, right arm, sequela','1997-02-27',151521,'0RWNX5Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
344,'Displaced fracture of proximal phalanx of other finger, initial encounter for closed fracture','2019-04-23',151491,'0GH','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
345,'Unspecified fracture of shaft of right femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with routine healing','2015-01-09',151513,'0SG84ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
346,'Other physeal fracture of lower end of humerus, right arm, subsequent encounter for fracture with delayed healing','2012-02-23',151518,'0X944ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
347,'Nondisplaced spiral fracture of shaft of left femur, subsequent encounter for open fracture type I or II with malunion','2009-08-20',151496,'03120K8','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
348,'Malignant neoplasm of lateral floor of mouth','2009-06-28',151524,'09RM3KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
349,'Displaced fracture of left tibial tuberosity, initial encounter for open fracture type I or II','2010-08-24',151515,'0RWE37Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
350,'Penetrating wound without foreign body of right eyeball','2001-09-27',151508,'0SHB38Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
351,'Salter-Harris Type I physeal fracture of lower end of radius, left arm','2015-04-14',151495,'0P5R0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
352,'Laceration of head of pancreas, unspecified degree, sequela','2002-03-12',151497,'02C73ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
353,'Unspecified dacryoadenitis, left lacrimal gland','1998-03-09',151526,'0SH33CZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
354,'Periprosthetic fracture around internal prosthetic joint','2004-04-22',151502,'041K0KJ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
355,'Chronic gout due to renal impairment, unspecified wrist, with tophus (tophi)','2019-01-02',151496,'09T04ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
356,'Anomalies of tooth position of fully erupted tooth or teeth','1996-11-26',151519,'047V4GZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
357,'Other specified injury of other blood vessels at hip and thigh level, unspecified leg','2003-11-17',151529,'0QWB35Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
358,'War operations involving chemical weapons and other forms of unconventional warfare','1992-09-27',151493,'037334Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
359,'Postdysenteric arthropathy, left shoulder','2001-04-17',151485,'0RPC34Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
360,'Subluxation of unspecified interphalangeal joint of unspecified thumb, subsequent encounter','2002-05-08',151505,'0RWQ4KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
361,'Recurrent and persistent hematuria with diffuse mesangiocapillary glomerulonephritis','1996-01-16',151526,'0RWK07Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
362,'Traumatic amputation of ear','1998-11-30',151499,'10Y03ZV','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
363,'Corrosion of first degree of left thigh, initial encounter','2000-11-13',151508,'0QRL4KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
364,'Benign neoplasm of left lacrimal gland and duct','2014-01-23',151497,'0RPG0JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
365,'Sprain of interphalangeal joint of left middle finger, subsequent encounter','2019-07-28',151504,'0V1N0JJ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
366,'String or thread causing external constriction, subsequent encounter','2011-06-10',151524,'0QU90JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
367,'Acute embolism and thrombosis of superficial veins of right upper extremity','2009-05-06',151509,'0RPK33Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
368,'Injury of right iliac artery, initial encounter','2017-03-18',151521,'0BM70ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
369,'Nondisplaced transverse fracture of shaft of left femur','2011-01-09',151533,'037H0E6','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
370,'Rheumatoid arthritis of unspecified knee with involvement of other organs and systems','2004-01-06',151514,'2W0SX5Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
371,'Maternal care for other specified fetal problems, unspecified trimester','2009-05-02',151508,'0SPU0JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
372,'Other fracture of head and neck of right femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','1990-07-11',151531,'047D35Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
373,'Displaced midcervical fracture of left femur','2016-12-20',151527,'041C49K','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
374,'Unspecified disorder of binocular vision','2009-09-06',151506,'039C4ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
375,'4-part fracture of surgical neck of right humerus, subsequent encounter for fracture with delayed healing','2002-03-01',151490,'0RPB47Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
376,'Striking against unspecified object with subsequent fall, sequela','2016-01-28',151510,'0FL93DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
377,'Idiopathic aseptic necrosis of hand and fingers','1993-10-15',151520,'F06Z0YZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
378,'Hypersensitivity angiitis','2003-04-26',151514,'F08F5CZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
379,'Other instability, ankle and foot','2014-03-22',151522,'027J04Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
380,'Laceration with foreign body of right front wall of thorax with penetration into thoracic cavity, subsequent encounter','1992-08-05',151522,'047H356','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
381,'Corrosion of third degree of left axilla, sequela','1999-08-12',151511,'F13Z7KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
382,'Puncture wound without foreign body of unspecified wrist, initial encounter','1992-05-18',151516,'0U7K8DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
383,'Toxic effect of venom of centipedes and venomous millipedes, accidental (unintentional), subsequent encounter','1992-01-18',151511,'07WN00Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
384,'Corneal scars and opacities','1995-06-05',151528,'05C80ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
385,'Corrosion of third degree of buttock, subsequent encounter','1990-05-09',151516,'0LQ23ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
386,'Open bite of left back wall of thorax without penetration into thoracic cavity, initial encounter','2015-12-18',151527,'0RC','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
387,'Dislocation of metacarpophalangeal joint of left ring finger, initial encounter','1992-06-12',151518,'0QW837Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
388,'Pedestrian on foot injured in collision with two- or three-wheeled motor vehicle in traffic accident','2007-07-04',151515,'0DP68DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
389,'Gaucher disease','2013-05-19',151495,'021K0JR','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
390,'Flail joint, knee','2014-11-22',151521,'047D0E6','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
391,'Passenger in pick-up truck or van injured in collision with two- or three-wheeled motor vehicle in traffic accident, initial encounter','2001-03-19',151503,'07WK47Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
392,'Breakdown (mechanical) of vascular dialysis catheter, initial encounter','1999-03-08',151494,'03V53DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
393,'Newborn affected by abnormality in fetal (intrauterine) heart rate or rhythm, unspecified as to time of onset','1991-04-07',151508,'0N963ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
394,'Poisoning by, adverse effect of and underdosing of other antihypertensive drugs','2016-02-07',151518,'0UB74ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
395,'Secondary pigmentary degeneration, bilateral','2002-01-23',151507,'0SPN05Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
396,'Toxic effect of formaldehyde','2010-01-27',151515,'0CWSXJZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
397,'Burn of unspecified degree of multiple sites of left shoulder and upper limb, except wrist and hand, initial encounter','2018-01-11',151512,'0KWY47Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
398,'Hemarthrosis, right wrist','2015-07-07',151529,'0CLC3DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
399,'Displaced fracture of base of neck of unspecified femur, subsequent encounter for closed fracture with nonunion','1997-08-13',151514,'025F4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
400,'Injury of abducent nerve, unspecified side, initial encounter','2011-09-06',151488,'0XUC47Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
401,'Poisoning by selective serotonin reuptake inhibitors, undetermined, sequela','2019-06-09',151528,'0NH03MZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
402,'Unspecified injury of other blood vessels at wrist and hand level','2016-05-30',151509,'3E0V3GB','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
403,'Driver of pick-up truck or van injured in collision with heavy transport vehicle or bus in nontraffic accident, subsequent encounter','2000-01-04',151528,'0YUC0JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
404,'Osteopathy after poliomyelitis, lower leg','1992-11-07',151500,'0TNB3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
405,'Strain of muscle and tendon of long extensor muscle of toe at ankle and foot level, right foot, subsequent encounter','1996-03-10',151509,'03HY03Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
406,'Lateral subluxation of right patella','1997-01-01',151525,'0XB44ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
407,'Unspecified chronic conjunctivitis, unspecified eye','1991-08-22',151495,'0KBV3ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
408,'Nondisplaced unspecified condyle fracture of lower end of unspecified femur, subsequent encounter for open fracture type I or II with nonunion','1992-12-02',151532,'0RWW30Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
409,'Unspecified fracture of shaft of ulna','2002-08-16',151497,'B5100ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
410,'Niemann-Pick disease, unspecified','2017-05-10',151533,'00XQ4ZF','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
411,'Burn of unspecified degree of abdominal wall, initial encounter','2015-10-10',151506,'F02ZCUZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
412,'Collapsed vertebra, not elsewhere classified, sacral and sacrococcygeal region','1998-06-15',151520,'047K3DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
413,'Fall from playground swing, subsequent encounter','2003-06-16',151497,'0D597ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
414,'Pigmentary glaucoma, left eye','2013-06-04',151518,'0PSQ34Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
415,'Driver of pick-up truck or van injured in noncollision transport accident in nontraffic accident','1995-01-02',151510,'0LN54ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
416,'Suppurative otitis media, unspecified, left ear','1992-06-06',151488,'B5180ZA','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
417,'Triplet pregnancy, unspecified number of placenta and unspecified number of amniotic sacs, second trimester','2011-11-17',151499,'0CU00KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
418,'Other specified disorders of cartilage, forearm','1990-11-22',151520,'035','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
419,'Contact with nail gun, initial encounter','2012-05-28',151525,'0JH83WZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
420,'Other specified injury of unspecified innominate or subclavian vein','2003-06-03',151529,'0WPP71Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
421,'Food in respiratory tract, part unspecified causing other injury, sequela','2015-06-08',151495,'0DH803Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
422,'Burn of third degree of left ankle, initial encounter','2002-07-15',151488,'0QUB4KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
423,'Other specified congenital malformations of face and neck','1998-01-31',151510,'04963ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
424,'Other specified injury of ulnar artery at wrist and hand level of right arm, sequela','2018-04-27',151489,'0PC24ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
425,'Adverse effect of thrombolytic drugs, sequela','1995-06-13',151505,'DT1199Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
426,'Unspecified fracture of shaft of humerus, unspecified arm, subsequent encounter for fracture with routine healing','2011-06-01',151504,'0RWN0JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
427,'Contusion of left hand, sequela','2000-10-22',151509,'3E0H86Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
428,'Other acute pancreatitis','2005-03-03',151532,'049H0ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
429,'Toxic effect of lead and its compounds, intentional self-harm','1990-12-28',151514,'05W33MZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
430,'Pedestrian injured in traffic accident involving military vehicle, sequela','2003-12-05',151524,'05U137Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
431,'Alcohol dependence with alcohol-induced sleep disorder','1994-08-31',151500,'04LR4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
432,'Non-pressure chronic ulcer of unspecified part of right lower leg with necrosis of bone','2003-08-20',151515,'2W28X4Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
433,'Sprain of medial collateral ligament of unspecified knee, sequela','2007-06-30',151532,'0RPX4KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
434,'Newborn affected by abnormality in fetal (intrauterine) heart rate or rhythm','2012-11-15',151490,'03130KF','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
435,'Fracture of unspecified part of neck of right femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','1994-06-17',151502,'0DH83DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
436,'Unspecified subluxation of left sternoclavicular joint, initial encounter','2005-02-28',151502,'0PBC0ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
437,'Poisoning by hydantoin derivatives, undetermined, sequela','2007-10-10',151528,'0RCE0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
438,'Fracture of unspecified part of scapula, right shoulder, initial encounter for closed fracture','2006-04-14',151502,'0KNS0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
439,'Post-traumatic headache, unspecified, intractable','1993-10-21',151492,'0M9G0ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
440,'Parachutist injured on landing, initial encounter','2001-12-03',151509,'DT10B7Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
441,'Filariasis, unspecified','1993-12-23',151517,'BQ3WZZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
442,'War operations involving other fires, conflagrations and hot substances, civilian, subsequent encounter','2014-01-10',151529,'07QF4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
443,'Dysplasia of vagina, unspecified','1995-09-22',151506,'0LPY47Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
444,'Poisoning by unspecified drugs primarily affecting the autonomic nervous system, intentional self-harm, subsequent encounter','1993-06-03',151511,'0BM50ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
445,'Other osteoporosis with current pathological fracture, unspecified humerus','1990-08-24',151525,'0SGB34Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
446,'Nondisplaced fracture of base of neck of left femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with malunion','2018-01-09',151528,'0DV93ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
447,'Blister (nonthermal) of right thumb','1993-03-29',151488,'03UD3KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
448,'Injury of optic nerve, right eye','2018-03-25',151529,'05SD3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
449,'Third degree perineal laceration during delivery, unspecified','2003-03-25',151493,'03UY3KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
450,'Stable burst fracture of second lumbar vertebra, subsequent encounter for fracture with delayed healing','1997-06-28',151509,'0PB10ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
451,'Newborn light for gestational age','2004-09-20',151485,'0KXN4Z1','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
452,'Other complication of vascular dialysis catheter, initial encounter','1992-11-18',151493,'3E0Y304','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
453,'Unspecified open wound, unspecified ankle','2001-11-22',151508,'06CT3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
454,'Struck by chicken','2010-01-25',151497,'F0CH3UZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
455,'Pathological fracture in neoplastic disease, left shoulder, subsequent encounter for fracture with nonunion','2012-08-07',151506,'0DJUXZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
456,'Gummata and ulcers of yaws','2014-11-19',151505,'06533ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
457,'Other forms of scoliosis, lumbar region','2018-04-23',151497,'06RB07Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
458,'Multiple fractures of ribs, left side, sequela','2017-03-24',151498,'0D720DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
459,'Toxic effect of ethanol','1995-04-13',151494,'0MB70ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
460,'Laceration of muscle, fascia and tendon of triceps, right arm','2010-01-07',151503,'0UP88DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
461,'Injury of deep peroneal nerve at ankle and foot level, unspecified leg, sequela','2017-08-13',151520,'0D9C0ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
462,'Other injury of flexor muscle, fascia and tendon of left ring finger at forearm level','2002-04-25',151527,'0T134J9','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
463,'Blister (nonthermal) of lower back and pelvis, subsequent encounter','1997-01-29',151502,'0P574ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
464,'Low lying placenta NOS or without hemorrhage','2009-02-04',151521,'9WB9XHZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
465,'Pathological fracture in neoplastic disease, left tibia, subsequent encounter for fracture with malunion','1990-05-21',151528,'03NR4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
466,'Passenger in pick-up truck or van injured in collision with heavy transport vehicle or bus in traffic accident, sequela','2011-04-23',151519,'B41FYZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
467,'Pathological fracture, unspecified femur, subsequent encounter for fracture with delayed healing','2017-07-06',151514,'04WYX0Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
468,'Nondisplaced supracondylar fracture without intracondylar extension of lower end of unspecified femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','2011-04-10',151518,'0L9D4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
469,'Traumatic rupture of unspecified ligament of unspecified wrist','1996-12-31',151500,'03VC0DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
470,'ST elevation (STEMI) myocardial infarction involving right coronary artery','1994-10-15',151486,'0DUN8KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
471,'Other mechanical complication of aortic (bifurcation) graft (replacement), initial encounter','2004-03-25',151511,'0P9M30Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
472,'Fecal incontinence','1995-08-26',151502,'0JHC3NZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
473,'Infection and inflammatory reaction due to ventricular intracranial (communicating) shunt, subsequent encounter','2000-01-03',151495,'0NR10JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
474,'Other headache syndrome','2018-03-02',151528,'02L','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
475,'Laceration without foreign body of unspecified eyelid and periocular area','2008-10-01',151505,'09BW4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
476,'Double pterygium of unspecified eye','2014-05-07',151495,'0QU10JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
477,'Nondisplaced osteochondral fracture of right patella, subsequent encounter for closed fracture with malunion','1998-01-27',151516,'0B958ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
478,'Secondary osteoarthritis, unspecified elbow','2006-08-06',151504,'08VX3ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
479,'Pauciarticular juvenile rheumatoid arthritis, shoulder','1995-09-03',151491,'0DWV3KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
480,'Retained foreign body in right upper eyelid','2002-08-13',151499,'0DQP0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
481,'Pathological fracture in neoplastic disease, left ulna, sequela','1991-02-15',151496,'04VL0CZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
482,'Strain of muscle(s) and tendon(s) of the rotator cuff of unspecified shoulder, initial encounter','2008-02-15',151491,'0PR70KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
483,'Anodontia','2000-04-06',151509,'0M9340Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
484,'Other fracture of upper end of right tibia, subsequent encounter for closed fracture with delayed healing','2005-03-04',151497,'0NR307Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
485,'Strain of muscle, fascia and tendon of triceps, left arm','2006-04-29',151513,'08UY7JZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
486,'Atherosclerotic heart disease of native coronary artery without angina pectoris','2005-08-16',151520,'0D1387A','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
487,'Other superficial bite of lip and oral cavity','2011-11-28',151495,'0FWB30Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
488,'Open bite of left back wall of thorax with penetration into thoracic cavity','2004-08-16',151514,'0UQMXZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
489,'Military operations involving direct blast effect of nuclear weapon, civilian, sequela','2007-02-28',151484,'0SWG34Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
490,'Unspecified injury of intrinsic muscle, fascia and tendon of right thumb at wrist and hand level','1991-09-17',151491,'0RWV40Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
491,'Fracture of anterior wall of acetabulum','2006-04-09',151518,'0RHU38Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
492,'Calcific tendinitis, right hand','2016-07-26',151518,'0YBN4ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
493,'Poisoning by other general anesthetics, assault, sequela','1990-10-20',151531,'3E0E8TZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
494,'Unspecified fracture of unspecified toe(s), sequela','1997-03-04',151485,'0KQN0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
495,'Pedestrian injured in unspecified transport accident, initial encounter','2017-01-04',151523,'0RUV37Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
496,'Disease of upper respiratory tract, unspecified','1991-03-07',151500,'0DLC0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
497,'Nondisplaced bicondylar fracture of right tibia, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with routine healing','2013-04-28',151528,'0Y6T0Z2','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
498,'Other Hodgkin lymphoma, intrapelvic lymph nodes','2002-05-15',151522,'0LRN07Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
499,'Sprain of unspecified collateral ligament of left knee','1996-11-27',151526,'09BP0ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
500,'Unspecified injury of flexor muscle, fascia and tendon of right ring finger at wrist and hand level','2011-07-07',151505,'0RR','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
501,'Other fracture of head and neck of left femur, subsequent encounter for open fracture type I or II with routine healing','1991-09-11',151508,'D0073Z0','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
502,'Pulmonary embolism without acute cor pulmonale','2004-04-16',151492,'0FPB7KZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
503,'Other injury of intrinsic muscle, fascia and tendon of left middle finger at wrist and hand level, initial encounter','2003-10-15',151521,'0CQV0ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
504,'Failure in dosage in electroshock or insulin-shock therapy','1996-01-26',151486,'041K0KQ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
505,'Displaced fracture of epiphysis (separation) (upper) of left femur, initial encounter for closed fracture','1993-02-25',151510,'B908YZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
506,'Person injured while boarding or alighting from aircraft, initial encounter','2007-10-06',151508,'0CR','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
507,'Toxic effect of carbon dioxide, accidental (unintentional), subsequent encounter','1990-01-19',151517,'02HR3DZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
508,'Fall from scooter (nonmotorized), subsequent encounter','1992-10-15',151523,'0C973ZX','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
509,'Foreign body on external eye, part unspecified, right eye, initial encounter','2017-07-06',151512,'0SWHX5Z','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
510,'Subacute osteomyelitis, unspecified femur','1994-07-07',151519,'DG25HZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
511,'Driver of heavy transport vehicle injured in collision with other nonmotor vehicle in nontraffic accident','2014-03-28',151522,'DVY08ZZ','postgres','2017-09-11 10:02:43.576','postgres','2017-09-11 10:02:43.576');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
512,'Nondisplaced pilon fracture of unspecified tibia, initial encounter for closed fracture','2009-02-18',151517,'0F968ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
513,'Ankylosis, unspecified wrist','1997-09-29',151491,'0JX90ZC','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
514,'Pedestrian on foot injured in collision with heavy transport vehicle or bus, unspecified whether traffic or nontraffic accident, subsequent encounter','2007-03-13',151530,'0J5L0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
515,'Spontaneous rupture of flexor tendons, unspecified shoulder','2005-04-23',151509,'037N4G6','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
516,'Displaced fracture of trapezium [larger multangular], left wrist, subsequent encounter for fracture with routine healing','2001-03-04',151500,'04753Z6','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
517,'Unspecified injury of long flexor muscle, fascia and tendon of right thumb at wrist and hand level, initial encounter','2005-09-11',151513,'0TJ98ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
518,'Other specified disorders of tendon, left elbow','2009-10-15',151510,'07V30CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
519,'Abscess of bursa, unspecified hip','2008-11-02',151489,'0RWEX0Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
520,'Salter-Harris Type II physeal fracture of upper end of right fibula','2015-08-20',151521,'0LU44JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
521,'Abnormal level of enzymes in specimens from respiratory organs and thorax','1999-06-03',151533,'03160J5','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
522,'Other dislocation of unspecified shoulder joint, initial encounter','2018-12-14',151522,'0D15474','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
523,'Displaced fracture of lower epiphysis (separation) of right femur, subsequent encounter for open fracture type I or II with delayed healing','2012-08-23',151493,'0HBX7ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
524,'Terrorism involving firearms, public safety official injured, sequela','2008-05-31',151525,'0G534ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
525,'Strain of muscle(s) and tendon(s) of peroneal muscle group at lower leg level, right leg, sequela','1996-01-27',151523,'0KNQXZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
526,'Superficial foreign body of right thumb, sequela','2012-04-28',151485,'0FV90DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
527,'Complete lesion of L1 level of lumbar spinal cord, sequela','2011-03-10',151510,'0DBP0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
528,'Unspecified episcleritis, right eye','2009-06-29',151521,'B2110ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
529,'Adverse effect of butyrophenone and thiothixene neuroleptics','2004-02-18',151532,'0MUK4JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
530,'Traumatic rupture of other ligament of other finger at metacarpophalangeal and interphalangeal joint, sequela','2005-09-24',151487,'037G356','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
531,'Postprocedural hemorrhage of a genitourinary system organ or structure following other procedure','1993-08-04',151494,'0VNF0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
532,'Traumatic shock','2003-11-13',151506,'0SR9039','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
533,'Toxic effect of venom of other snake, accidental (unintentional), sequela','1999-03-15',151532,'0YB73ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
534,'Burn of third degree of multiple sites of right wrist and hand, sequela','2000-09-12',151522,'0PUR47Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
535,'Pedal cycle driver injured in collision with two- or three-wheeled motor vehicle in nontraffic accident','2015-09-02',151494,'4A05XLZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
536,'Laryngeal hypoplasia','1994-02-23',151499,'30260K0','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
537,'Other psychoactive substance dependence with psychoactive substance-induced psychotic disorder','1992-02-23',151504,'02UR3KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
538,'Pain due to genitourinary prosthetic devices, implants and grafts, subsequent encounter','2015-11-07',151484,'089','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
539,'Unspecified juvenile rheumatoid arthritis, right ankle and foot','2011-12-01',151486,'0P910ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
540,'Hemorrhage from respiratory passages','2014-09-08',151485,'05P43MZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
541,'Anaplastic large cell lymphoma, ALK-positive','1990-04-09',151493,'0KU147Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
542,'Person on outside of car injured in collision with railway train or railway vehicle in nontraffic accident, subsequent encounter','1996-08-10',151511,'0KB90ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
543,'Laceration without foreign body of left upper arm, subsequent encounter','2017-04-23',151524,'0U154K6','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
544,'Premature rupture of membranes','1999-09-07',151496,'00NC4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
545,'Toxic effect of other organic solvents, accidental (unintentional), initial encounter','1994-03-22',151522,'037F4FZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
546,'Nondisplaced intraarticular fracture of right calcaneus, initial encounter for open fracture','2014-08-01',151489,'DU020ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
547,'Pathological fracture, right hand, initial encounter for fracture','2013-07-11',151509,'0DFK4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
548,'Underdosing of immunoglobulin, initial encounter','2018-07-14',151511,'0X093KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
549,'Incompetence of cervix uteri','1990-04-05',151495,'04CT4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
550,'ABO incompatibility with hemolytic transfusion reaction, unspecified, subsequent encounter','1993-03-02',151487,'0UBG3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
551,'Alzheimer''s disease with early onset','2004-10-09',151491,'B309YZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
552,'Unspecified injury of extensor muscle, fascia and tendon of unspecified thumb at wrist and hand level','1994-04-14',151490,'0SQN0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
553,'Toxic effect of venom of bees, undetermined','2001-05-17',151528,'0TVDXZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
554,'Pterygium of eye','1993-10-13',151501,'037M346','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
555,'Contusion of left wrist, subsequent encounter','2016-02-07',151514,'0L9F0ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
556,'Other specified injury of muscle and tendon of long extensor muscle of toe at ankle and foot level, left foot, initial encounter','2005-02-02',151500,'0S5C3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
557,'Laceration of abdominal wall with foreign body, right upper quadrant without penetration into peritoneal cavity, sequela','1995-10-09',151514,'0VWSX3Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
558,'Other osteoporosis with current pathological fracture, unspecified ankle and foot, subsequent encounter for fracture with delayed healing','2006-05-27',151507,'06NP3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
559,'Poisoning by otorhinolaryngological drugs and preparations, assault, subsequent encounter','1996-06-28',151531,'0N534ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
560,'Supervision of high risk pregnancy, unspecified, third trimester','1998-10-14',151516,'049J3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
561,'Driver of three-wheeled motor vehicle injured in collision with pedestrian or animal in traffic accident','2004-02-08',151519,'0MT90ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
562,'Poisoning by antidiarrheal drugs, intentional self-harm, sequela','2018-04-13',151489,'3E0T3BZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
563,'Unspecified injury of lung, unilateral, sequela','2012-11-11',151525,'04H033Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
564,'Unspecified injury of inferior mesenteric vein, initial encounter','1998-12-05',151511,'04CH4Z6','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
565,'Unspecified pre-existing diabetes mellitus in pregnancy, childbirth and the puerperium','2005-03-03',151503,'051H4ZY','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
566,'Osteonecrosis due to previous trauma of right ulna','1993-12-27',151514,'0D9C80Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
567,'Unspecified occupant of three-wheeled motor vehicle injured in collision with railway train or railway vehicle in nontraffic accident','2019-07-11',151528,'0H0V37Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
568,'Crushing injury of left ankle, sequela','2014-05-18',151492,'039Q40Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
569,'Nondisplaced spiral fracture of shaft of unspecified fibula, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with malunion','2012-09-08',151509,'01983ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
570,'Spinal stenosis, cervicothoracic region','2012-10-22',151512,'3E0U3GC','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
571,'Minor laceration of left external jugular vein, initial encounter','1998-05-15',151527,'B335YZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
572,'Corrosion of third degree of multiple sites of left lower limb, except ankle and foot, sequela','1993-02-13',151506,'04V00ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
573,'Sprain of unspecified ligament of left ankle, sequela','2015-12-18',151520,'0J8K0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
574,'Unspecified fracture of shaft of unspecified fibula, subsequent encounter for open fracture type I or II with malunion','1990-04-20',151522,'0QWD4JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
575,'Displaced fracture of medial phalanx of left ring finger, sequela','2000-10-03',151516,'0PP744Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
576,'Hyperstimulation of ovaries','2015-06-05',151526,'0KC','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
577,'Postprocedural  cardiogenic shock, initial encounter','2000-10-26',151503,'0DVQXCZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
578,'Abrasion of right wrist, initial encounter','2017-01-15',151510,'0S9N4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
579,'Unspecified superficial injury of unspecified foot','2018-01-17',151522,'03NJ0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
580,'Displaced fracture of distal phalanx of left thumb, subsequent encounter for fracture with malunion','2007-01-10',151491,'031G0ZG','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
581,'Military operations involving fragments from munitions, military personnel','2010-03-05',151503,'039D40Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
582,'Unspecified injury of extensor muscle, fascia and tendon of right thumb at wrist and hand level, initial encounter','2009-11-08',151517,'0SPD4KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
583,'Acquired clawfoot, left foot','2008-06-27',151503,'BT1F1ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
584,'Contracture, unspecified shoulder','2015-01-20',151522,'B405YZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
585,'Partial traumatic amputation of right hand at wrist level, sequela','1996-02-11',151508,'041J0AB','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
586,'Unstable burst fracture of first lumbar vertebra, subsequent encounter for fracture with nonunion','2005-08-13',151517,'07PK40Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
587,'Displaced fracture of lateral condyle of left femur, subsequent encounter for open fracture type I or II with routine healing','1997-04-27',151501,'0P593ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
588,'Puncture wound without foreign body of right great toe with damage to nail, sequela','2002-04-15',151516,'0KBS3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
589,'Subluxation of distal interphalangeal joint of right index finger','2007-04-16',151503,'05C94ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
590,'Contact with metalworking machines, subsequent encounter','2010-11-19',151503,'0NN','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
591,'Nondisplaced fracture of distal phalanx of left ring finger, sequela','2007-05-21',151501,'05VN0CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
592,'Mechanical entropion of eyelid','2000-07-06',151528,'0JH70MZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
593,'Unspecified occupant of bus injured in collision with pedestrian or animal in nontraffic accident, sequela','2012-04-07',151519,'0VBL0ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
594,'Other fracture of shaft of left fibula, subsequent encounter for open fracture type I or II with routine healing','1998-08-18',151508,'0GQF4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
595,'Unspecified injury of unspecified blood vessel of thorax, initial encounter','1990-11-11',151530,'0D1M4KM','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
596,'Labor and delivery complicated by umbilical cord complications','2008-10-19',151518,'047907Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
597,'Unspecified fracture of right wrist and hand','2007-02-01',151490,'BF1','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
598,'Unspecified acquired deformity of thigh','1992-02-11',151522,'0SGG44Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
599,'Nondisplaced fracture of lesser trochanter of unspecified femur, subsequent encounter for closed fracture with routine healing','1993-02-12',151500,'085','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
600,'Other nondisplaced fracture of base of first metacarpal bone, unspecified hand, sequela','2013-03-04',151497,'0M9B0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
601,'Open bite of right wrist, initial encounter','1990-08-01',151492,'05LR4DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
602,'Galeazzi''s fracture of unspecified radius, initial encounter for open fracture type I or II','2015-12-29',151510,'0M5N0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
603,'Car driver injured in collision with sport utility vehicle in traffic accident','2011-05-19',151501,'06R34KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
604,'Personal history of other diseases of the musculoskeletal system and connective tissue','1994-10-09',151493,'06S13ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
605,'Insect bite (nonvenomous) of right back wall of thorax, sequela','1993-10-09',151517,'035R4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
606,'Poisoning by antirheumatics, not elsewhere classified, undetermined, sequela','2019-05-08',151514,'BG230ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
607,'Adverse effect of unspecified systemic antibiotic, sequela','2015-12-18',151485,'021Q08B','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
608,'Pregnancy care for patient with recurrent pregnancy loss, first trimester','2006-03-16',151489,'04CJ3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
609,'Neonatal aspiration of milk and regurgitated food with respiratory symptoms','1997-12-05',151485,'0KBM3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
610,'Alcoholic hepatitis','2010-02-25',151508,'0JNQXZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
611,'Type 1 diabetes mellitus with ketoacidosis with coma','2009-09-18',151519,'0Y0L3JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
612,'Open bite of vagina and vulva, initial encounter','2004-09-15',151513,'BH3FYZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
613,'Poisoning by loop [high-ceiling] diuretics, accidental (unintentional), sequela','2015-03-16',151496,'0RW037Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
614,'4-part fracture of surgical neck of left humerus, subsequent encounter for fracture with routine healing','1992-06-09',151494,'0FL50DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
615,'Nondisplaced intraarticular fracture of right calcaneus, initial encounter for open fracture','2009-06-20',151531,'03LC3CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
616,'Hereditary and idiopathic neuropathy, unspecified','2009-11-05',151500,'00F43ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
617,'Dislocation of C1/C2 cervical vertebrae, subsequent encounter','2000-01-09',151511,'4A0209Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
618,'Corrosion of first degree of unspecified thumb (nail), subsequent encounter','2016-12-31',151492,'01BQ3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
619,'Malignant carcinoid tumors of the small intestine','1993-09-13',151508,'0F20XYZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
620,'Monteggia''s fracture of ulna','1993-12-28',151531,'CW1BYZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
621,'Unspecified injury of other muscle(s) and tendon(s) at lower leg level, right leg','2016-08-17',151517,'0C9S8ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
622,'Superficial foreign body of right elbow','2005-03-19',151522,'BT210ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
623,'Unspecified open wound of pharynx and cervical esophagus, subsequent encounter','1999-04-13',151516,'0NBT3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
624,'Displacement of prosthetic orbit of right eye, initial encounter','2012-03-31',151490,'0RPR0KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
625,'Rat-bite fever, unspecified','2001-02-12',151532,'04CJ3Z6','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
626,'Staphylococcal arthritis, left knee','2002-04-23',151491,'0WJR4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
627,'Dining room in reform school as the place of occurrence of the external cause','2011-04-23',151522,'F07Z8CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
628,'Nondisplaced comminuted fracture of shaft of unspecified femur, initial encounter for open fracture type IIIA, IIIB, or IIIC','1998-09-30',151511,'DD002ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
629,'Adverse effect of unspecified antiepileptic and sedative-hypnotic drugs, sequela','2005-05-28',151485,'0RSEXZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
630,'Poisoning by salicylates, accidental (unintentional), sequela','2017-05-25',151509,'049N3ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
631,'Fracture of unspecified phalanx of other finger','1994-03-21',151508,'079P30Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
632,'Unspecified injury of unspecified ankle','1990-04-08',151512,'0D1L0KP','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
633,'Malignant neoplasm of central portion of breast','2012-02-13',151513,'037K4D6','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
634,'Displaced comminuted fracture of shaft of unspecified tibia, initial encounter for open fracture type IIIA, IIIB, or IIIC','2014-01-06',151530,'09WK30Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
635,'Salter-Harris Type III physeal fracture of right metatarsal, subsequent encounter for fracture with malunion','2019-06-29',151489,'0SWF04Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
636,'Poisoning by ophthalmological drugs and preparations, intentional self-harm','1991-03-23',151530,'02HP3DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
637,'3-part fracture of surgical neck of unspecified humerus, subsequent encounter for fracture with delayed healing','2012-07-23',151501,'3E0F8NZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
638,'Pedal cycle passenger injured in collision with heavy transport vehicle or bus in traffic accident, subsequent encounter','1999-01-16',151503,'0D9R4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
639,'Nondisplaced fracture of lateral condyle of unspecified humerus, initial encounter for open fracture','2005-06-23',151485,'0SPC43Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
640,'Maternal care for anti-D [Rh] antibodies','2009-08-19',151508,'0SWQ33Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
641,'Poisoning by antirheumatics, not elsewhere classified, assault','2018-02-25',151490,'0Q803ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
642,'Twin pregnancy, dichorionic/diamniotic','2012-04-15',151527,'0PST04Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
643,'Displaced fracture of distal phalanx of right great toe, subsequent encounter for fracture with delayed healing','1998-01-14',151532,'0SH948Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
644,'Displaced oblique fracture of shaft of right ulna, initial encounter for open fracture type IIIA, IIIB, or IIIC','1996-05-01',151523,'03B10ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
645,'Posterior dislocation of left humerus, initial encounter','1998-07-28',151530,'0RGD04Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
646,'Nondisplaced fracture of distal phalanx of unspecified finger, initial encounter for open fracture','2000-12-10',151529,'0P593ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
647,'Laceration without foreign body of abdominal wall, left upper quadrant with penetration into peritoneal cavity','1992-10-25',151506,'BR15ZZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
648,'Poisoning by other psychotropic drugs, intentional self-harm, sequela','1993-11-06',151506,'0NU33JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
649,'Displacement of breast prosthesis and implant','2013-05-07',151508,'0T164K7','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
650,'Other injury due to other accident on board merchant ship, sequela','2014-07-16',151490,'099G70Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
651,'Complete traumatic amputation of right foot, level unspecified, initial encounter','2010-03-02',151495,'089RXZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
652,'Fall on board merchant ship, subsequent encounter','2009-04-11',151503,'0DPD4CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
653,'Intentional self-harm by other specified means','2009-10-25',151533,'051R4KY','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
654,'Acute cholecystitis','2017-07-03',151524,'0YB60ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
655,'Other biomechanical lesions of abdomen and other regions','2000-06-13',151516,'0PP53KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
656,'Unspecified occupant of three-wheeled motor vehicle injured in collision with other nonmotor vehicle in nontraffic accident, subsequent encounter','1997-10-27',151518,'0BQK7ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
657,'Other noninfective acute otitis externa, left ear','2012-12-22',151519,'0RWK03Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
658,'Poisoning by unspecified systemic anti-infective and antiparasitics, accidental (unintentional), initial encounter','1996-08-24',151524,'0QHP45Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
659,'Sepsis due to Enterococcus','1999-09-08',151514,'0LQT0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
660,'Corpus luteum cyst of ovary, unspecified side','1998-03-04',151506,'00CQ4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
661,'Corrosion of first degree of neck, sequela','1994-09-25',151526,'0BW0XKZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
662,'Unspecified fracture of lower end of right femur, initial encounter for open fracture type I or II','2011-11-28',151501,'039B4ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
663,'Neoplasm of uncertain behavior of the major salivary glands, unspecified','1997-03-15',151507,'DD119BZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
664,'Displaced fracture of posterior wall of unspecified acetabulum, initial encounter for closed fracture','1990-07-18',151489,'037U466','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
665,'Burn of unspecified eye and adnexa, part unspecified, sequela','2011-02-18',151486,'0JHP0WZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
666,'Nondisplaced lateral mass fracture of first cervical vertebra, initial encounter for open fracture','2015-04-24',151492,'0UUG4JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
667,'Chronic angle-closure glaucoma, left eye, indeterminate stage','2017-02-03',151486,'0RPP00Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
668,'Unspecified injury of flexor muscle, fascia and tendon of left ring finger at wrist and hand level, sequela','2018-12-06',151528,'04CE0Z6','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
669,'Non-pressure chronic ulcer of unspecified ankle','1993-03-10',151527,'0D1K4KK','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
670,'Pathological fracture in neoplastic disease, right hand, subsequent encounter for fracture with routine healing','2009-05-20',151530,'0SRU0JA','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
671,'Childhood onset fluency disorder','1996-11-24',151493,'037305Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
672,'Garage of nursing home as the place of occurrence of the external cause','2015-05-31',151490,'09UL3KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
673,'Major contusion of right kidney, initial encounter','1993-12-23',151527,'0DB70ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
674,'Unspecified injury of diaphragm, subsequent encounter','2015-07-15',151494,'0QH905Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
675,'Osteopathy after poliomyelitis, left upper arm','1998-10-02',151505,'0BHK33Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
676,'Hyposplenism','1997-04-30',151507,'BP2M1ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
677,'Lateral dislocation of left ulnohumeral joint, sequela','2010-10-14',151491,'01894ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
678,'Adverse effect of antifungal antibiotics, systemically used','1992-10-21',151520,'0QS83CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
679,'Other specified injury of unspecified tibial artery, left leg','1998-10-02',151487,'0PR907Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
680,'Delayed hemolytic transfusion reaction, unspecified incompatibility, subsequent encounter','1999-10-10',151501,'0YJ70ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
681,'Displacement of internal fixation device of bone of right lower leg, subsequent encounter','1998-12-22',151519,'BW2100Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
682,'Rolling-type pedestrian conveyance accident','2012-11-06',151491,'0DLM7ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
683,'Cellulitis of back [any part except buttock]','2013-03-03',151512,'0FH233Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
684,'Stress fracture, ankle, foot and toes','2002-09-25',151516,'061J49Y','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
685,'Unspecified dislocation of left toe(s), sequela','2011-12-15',151513,'0KQF0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
686,'Type 1 fracture of sacrum, initial encounter for open fracture','2008-02-27',151497,'0RU907Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
687,'Osteopathy in diseases classified elsewhere, left thigh','2004-07-31',151492,'DB169CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
688,'Nondisplaced oblique fracture of shaft of right radius, subsequent encounter for closed fracture with nonunion','2002-05-14',151501,'0DH503Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
689,'Unspecified fracture of right patella','2010-05-08',151515,'0XUP4JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
690,'Nondisplaced fracture of distal phalanx of left index finger, subsequent encounter for fracture with delayed healing','2002-11-08',151523,'0XUL4JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
691,'Vitamin D deficiency, unspecified','2004-01-09',151530,'3E050KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
692,'External constriction of right wrist, sequela','1997-04-17',151516,'0UWD7DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
693,'Driver of snowmobile injured in nontraffic accident, initial encounter','2000-11-01',151485,'04HK0DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
694,'Instability of internal right knee prosthesis, initial encounter','1996-01-04',151525,'XRG6092','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
695,'Adverse effect of succinimides and oxazolidinediones','2004-11-30',151494,'F0756EZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
696,'Twin pregnancy, unspecified number of placenta and unspecified number of amniotic sacs, first trimester','1991-11-23',151487,'04104J0','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
697,'Nondisplaced fracture of medial phalanx of left ring finger','2012-12-25',151486,'05SH0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
698,'Posterior dislocation of right acromioclavicular joint, sequela','2014-06-19',151507,'0KQV3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
699,'Spondylolisthesis, lumbosacral region','2019-04-11',151523,'04UD37Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
700,'Unspecified injury of bronchus, unspecified','2016-10-16',151520,'0DL40CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
701,'Other cataclysmic storms, sequela','1993-05-21',151486,'04UJ47Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
702,'Other instability, right foot','2013-02-11',151508,'B5041ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
703,'Maternal care for anti-D [Rh] antibodies, third trimester, not applicable or unspecified','2011-06-02',151489,'04HK0DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
704,'Person boarding or alighting a pedal cycle injured in collision with car, pick-up truck or van, sequela','1993-03-16',151494,'03U73JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
705,'External constriction of right front wall of thorax, subsequent encounter','2015-03-06',151489,'06UG07Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
706,'Pyemic and septic embolism in pregnancy, second trimester','1997-06-12',151485,'F0726ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
707,'Subluxation and dislocation of C1/C2 cervical vertebrae','2008-01-19',151490,'0WPR4YZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
708,'Pathological fracture, right toe(s)','2004-04-13',151500,'0SP544Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
709,'Alveolitis of jaws','1998-06-02',151496,'00QH0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
710,'Other viral warts','2008-06-22',151495,'0PRH3KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
711,'Toxic effect of other corrosive organic compounds, intentional self-harm','2005-02-23',151528,'0LRT0JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
712,'Non-pressure chronic ulcer of left heel and midfoot with unspecified severity','2005-09-12',151494,'02TN3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
713,'Other kyphosis, site unspecified','2010-09-20',151499,'0PWR4JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
714,'Diffuse traumatic brain injury with loss of consciousness of 1 hour to 5 hours 59 minutes','1992-10-15',151526,'0SGF45Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
715,'Toxic effect of 2-Propanol, intentional self-harm, initial encounter','2006-10-13',151493,'0KQ30ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
716,'Primary angle closure without glaucoma damage, unspecified eye','2018-09-18',151506,'0QQG4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
717,'Encounter for supervision of normal first pregnancy, unspecified trimester','1994-06-28',151518,'07U00KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
718,'Sprain of joints and ligaments of unspecified parts of head','1997-01-29',151486,'05UD4JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
719,'Unspecified subluxation of left wrist and hand','2011-04-04',151485,'06CQ0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
720,'Other specified injury of posterior tibial artery, left leg, subsequent encounter','2006-07-05',151503,'0L9D0ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
721,'Partial traumatic amputation of midfoot','1991-05-10',151521,'0S9H00Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
722,'Displaced fracture of distal phalanx of right little finger, sequela','1991-08-27',151527,'02QP0ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
723,'Blepharophimosis unspecified eye, unspecified lid','2004-04-05',151502,'0D168KB','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
724,'Pathological fracture in neoplastic disease, right femur, subsequent encounter for fracture with malunion','2018-02-08',151529,'039S4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
725,'Laceration of axillary artery, left side, initial encounter','1999-06-07',151488,'0SW430Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
726,'Barton''s fracture of unspecified radius, subsequent encounter for closed fracture with routine healing','1993-02-13',151491,'047L4Z1','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
727,'Other fracture of fourth lumbar vertebra, initial encounter for closed fracture','1994-07-26',151528,'0SCH4ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
728,'Pain in shoulder','2018-02-03',151524,'0B788ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
729,'Other soft tissue disorders related to use, overuse and pressure','2014-11-05',151494,'03HR0DZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
730,'Contact with fats and cooking oils, sequela','2018-12-20',151505,'0DV40ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
731,'Person on outside of bus injured in collision with other nonmotor vehicle in traffic accident, sequela','2007-05-27',151525,'0YQ1XZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
732,'Other specified injury of intrinsic muscle and tendon at ankle and foot level, right foot, initial encounter','2001-06-30',151520,'0RWW0KZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
733,'Laceration of extensor or abductor muscles, fascia and tendons of left thumb at forearm level, subsequent encounter','1994-01-29',151494,'BP2UYZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
734,'Puncture wound with foreign body of right ear, sequela','2004-07-25',151490,'02C80ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
735,'Puncture wound without foreign body of right great toe with damage to nail','1994-05-19',151511,'0TP980Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
736,'Salter-Harris Type II physeal fracture of lower end of unspecified femur, subsequent encounter for fracture with delayed healing','1996-03-09',151503,'0P910ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
737,'Other specified albinism','1998-12-29',151505,'0D198K4','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
738,'Unspecified superficial injury of left hip, initial encounter','1997-04-22',151516,'009630Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
739,'Acquired stenosis of nasolacrimal duct','2000-02-06',151504,'02UL07Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
740,'Burn of unspecified degree of unspecified thumb (nail)','1998-10-30',151484,'0WP6XYZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
741,'Lateral subluxation of unspecified patella, initial encounter','1994-08-10',151518,'0J9H0ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
742,'Supervision of high risk pregnancy, unspecified, first trimester','1994-07-29',151502,'0MJYXZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
743,'Nondisplaced segmental fracture of shaft of ulna, left arm, sequela','1996-07-02',151494,'0D138ZA','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
744,'Atherosclerosis of native arteries of extremities with rest pain, unspecified extremity','1995-07-26',151529,'DBY08ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
745,'Complete traumatic metacarpophalangeal amputation of right thumb','2013-01-08',151500,'0MQ80ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
746,'Postauricular fistula, left ear','2008-04-21',151533,'0M9500Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
747,'Other cervical disc displacement, unspecified cervical region','1996-01-11',151492,'0SUW09Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
748,'Agoraphobia without panic disorder','2010-01-26',151487,'2W55X7Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
749,'Other fracture of lower end of left tibia, subsequent encounter for open fracture type I or II with routine healing','2012-08-10',151524,'06VF3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
750,'Finding of abnormal level of heavy metals in blood','2011-12-04',151530,'051347Y','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
751,'Driver of bus injured in noncollision transport accident in traffic accident, subsequent encounter','2004-07-23',151521,'0MB40ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
752,'Pressure ulcer of head, stage 4','2003-07-28',151494,'037S36Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
753,'Other bursitis, not elsewhere classified, ankle and foot','1999-06-11',151484,'DTY2FZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
754,'Animal-rider or occupant of animal-drawn vehicle injured in collision with car, pick-up truck, van, heavy transport vehicle or bus','2009-04-15',151532,'0JQ83ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
755,'Toxic effect of venom of other snake, intentional self-harm, subsequent encounter','2004-10-19',151485,'03140J2','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
756,'Burn of second degree of male genital region, initial encounter','1993-10-14',151494,'0RGS37Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
757,'Ascariasis pneumonia','2016-10-03',151506,'0QT40ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
758,'Nondisplaced longitudinal fracture of left patella, subsequent encounter for open fracture type I or II with nonunion','1999-12-25',151484,'03950ZX','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
759,'Thyrotoxicosis with toxic multinodular goiter','2010-10-09',151517,'03LH3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
760,'Poisoning by skeletal muscle relaxants [neuromuscular blocking agents], undetermined, initial encounter','2005-08-12',151520,'05SG3ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
761,'Displaced pilon fracture of right tibia, subsequent encounter for closed fracture with nonunion','2014-11-02',151518,'0KUS47Z','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
762,'Squamous cell carcinoma of skin of other parts of face','1998-11-15',151499,'0RJKXZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
763,'Intermittent hydrarthrosis, left shoulder','1990-03-22',151500,'0UP80CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
764,'Unspecified open wound of lower back and pelvis with penetration into retroperitoneum, subsequent encounter','1991-07-02',151507,'0RH10CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
765,'Plasmodium falciparum malaria, unspecified','1995-05-03',151508,'03V20CZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
766,'Complete lesion at unspecified level of thoracic spinal cord, initial encounter','2005-09-16',151510,'0LU24JZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
767,'Unspecified Shiga toxin-producing Escherichia coli [E. coli] (STEC) as the cause of diseases classified elsewhere','1997-11-05',151528,'0B548ZZ','postgres','2017-09-11 10:02:43.649','postgres','2017-09-11 10:02:43.649');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
768,'Inferior dislocation of right humerus','2000-08-22',151490,'03BC4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
769,'Laceration without foreign body of left elbow','2003-10-05',151485,'0TL70ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
770,'Injury of conjunctiva and corneal abrasion without foreign body, unspecified eye, sequela','2016-09-03',151514,'0QHB48Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
771,'Displaced fracture of medial condyle of unspecified humerus, subsequent encounter for fracture with nonunion','2001-10-09',151528,'0NRQ37Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
772,'Maternal care for intrauterine death, fetus 4','2012-06-22',151500,'06BP0ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
773,'Nondisplaced fracture of right ulna styloid process, subsequent encounter for open fracture type I or II with nonunion','2012-08-07',151513,'047134Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
774,'Malignant neoplasm of unspecified lacrimal gland and duct','2006-08-02',151515,'037P47Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
775,'Paralytic calcification and ossification of muscle, left thigh','2012-10-16',151528,'0RPR40Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
776,'Other fracture of occiput, unspecified side','2010-09-18',151515,'0G9140Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
777,'Rheumatoid arthritis without rheumatoid factor, right hip','2002-01-06',151527,'0PN14ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
778,'Nondisplaced longitudinal fracture of unspecified patella, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with malunion','2005-01-06',151511,'0MCL4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
779,'Benign endometrial hyperplasia','2000-11-11',151525,'0TH972Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
780,'Underdosing of androgens and anabolic congeners, sequela','2004-03-19',151508,'0PU137Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
781,'Other fracture of fifth metacarpal bone, right hand, subsequent encounter for fracture with malunion','2007-08-30',151505,'0CBS4ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
782,'Salter-Harris Type I physeal fracture of lower end of radius, left arm, initial encounter for closed fracture','2018-03-13',151511,'00NG4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
783,'Displaced fracture of pisiform, unspecified wrist, initial encounter for open fracture','2018-07-14',151484,'BR06ZZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
784,'Military operations involving thermal radiation effect of nuclear weapon, civilian','1996-08-24',151511,'065F0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
785,'Unspecified fracture of lower end of left tibia, subsequent encounter for open fracture type I or II with delayed healing','2008-06-09',151491,'BU36YZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
786,'Abrasion of left middle finger, subsequent encounter','2003-07-15',151508,'0CQWXZ1','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
787,'Pathological fracture in neoplastic disease, right fibula, sequela','2010-03-15',151522,'0DR50JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
788,'Crushing injury of other specified parts of neck, subsequent encounter','1993-08-13',151504,'0D9G7ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
789,'Chronic multifocal osteomyelitis, other site','2015-10-19',151494,'04100J7','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
790,'Unspecified open wound of other specified part of neck, subsequent encounter','2009-05-04',151491,'0TR40JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
791,'Acquired atrophy of left ovary','2000-10-30',151505,'037S0G6','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
792,'Crushing injury of unspecified toe(s), subsequent encounter','2007-04-04',151522,'07UK4JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
793,'Postprocedural hemorrhage of a circulatory system organ or structure following cardiac bypass','2000-03-03',151489,'0RP438Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
794,'Unspecified fracture of upper end of right tibia, initial encounter for open fracture type I or II','1992-05-30',151497,'0KN70ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
795,'External constriction of unspecified ear, subsequent encounter','2015-12-03',151500,'06RQ0JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
796,'Spontaneous rupture of extensor tendons, right lower leg','2003-02-10',151497,'0N8K4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
797,'Toxic effect of carbon tetrachloride, assault, sequela','2014-07-17',151497,'04NU4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
798,'Other specified injury of unspecified blood vessel at wrist and hand of right arm','2005-09-18',151530,'07PM40Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
799,'Activity, other involving exterior property and land maintenance, building and construction','2013-11-03',151505,'05UA4JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
800,'Other exposure to uncontrolled fire in building or structure, initial encounter','2009-07-30',151498,'0BQ30ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
801,'Unspecified fracture of third thoracic vertebra, sequela','1995-03-08',151517,'0LB13ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
802,'Unstable burst fracture of second thoracic vertebra, initial encounter for closed fracture','1995-06-25',151517,'0QWD37Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
803,'Salter-Harris Type I physeal fracture of left metatarsal, sequela','1990-07-24',151500,'047N47Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
804,'Chronic angle-closure glaucoma, right eye, mild stage','1994-11-10',151501,'0D9H4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
805,'Partial traumatic transmetacarpal amputation of hand','2003-07-03',151517,'04C10Z6','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
806,'Gout due to renal impairment, hip','1990-02-05',151497,'0RP0X3Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
807,'Passenger on bus injured in collision with railway train or railway vehicle in nontraffic accident, sequela','1995-01-12',151501,'0HUX8KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
808,'Other enthesopathy of foot','2017-07-13',151526,'04RM07Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
809,'Postimmunization arthropathy, multiple sites','2014-07-24',151490,'089P30Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
810,'Mechanical complication of other vascular grafts','2016-06-17',151487,'0B9R40Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
811,'Familial chondrocalcinosis, left knee','1994-12-03',151490,'0PBN0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
812,'Congenital pneumonia due to Pseudomonas','2003-02-16',151518,'D91F9BZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
813,'Phlebitis and thrombophlebitis of left tibial vein','2002-10-21',151497,'0W1G4J4','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
814,'Corrosion of first degree of unspecified thigh, initial encounter','2009-04-17',151507,'8E0XXBG','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
815,'Osteochondritis dissecans, left ankle and joints of left foot','2016-04-29',151523,'0Y0K4JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
816,'Ocular pain, bilateral','1995-02-18',151497,'04UL0JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
817,'Sylvatic rabies','2014-11-07',151515,'F0746CZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
818,'Nondisplaced fracture of distal phalanx of right great toe, subsequent encounter for fracture with delayed healing','1998-02-18',151512,'0RHQ33Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
819,'Other disorders of patella, unspecified knee','1997-03-26',151497,'D917B8Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
820,'Congenital malformations of gallbladder, bile ducts and liver','2013-11-01',151513,'0TC','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
821,'Other specified injury of greater saphenous vein at hip and thigh level, unspecified leg, sequela','2005-09-10',151517,'0RNUXZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
822,'Exposure to sofa fire due to other burning material, subsequent encounter','2013-02-17',151513,'0RGF37Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
823,'Sprain of tibiofibular ligament of unspecified ankle, sequela','2005-09-05',151521,'03994ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
824,'Nondisplaced transverse fracture of shaft of unspecified tibia, subsequent encounter for closed fracture with routine healing','2013-11-18',151512,'0LT54ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
825,'Emphysema (subcutaneous) resulting from a procedure','1991-06-03',151501,'059G00Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
826,'Dislocation of C5/C6 cervical vertebrae','2002-09-04',151514,'0PN60ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
827,'Underdosing of unspecified hormones and synthetic substitutes, subsequent encounter','2011-02-10',151526,'02UM3KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
828,'War operations involving fragments of improvised explosive device [IED], civilian, sequela','1994-11-19',151490,'0XHK43Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
829,'Pedal cycle passenger injured in collision with pedestrian or animal in nontraffic accident, subsequent encounter','1999-11-30',151512,'0UQG3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
830,'Displacement of cystostomy catheter, initial encounter','2017-02-22',151491,'3E033U0','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
831,'Other chorioretinal inflammations, unspecified eye','1992-12-29',151493,'099L3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
832,'Salter-Harris Type IV physeal fracture of phalanx of unspecified toe, sequela','2006-01-20',151505,'0N853ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
833,'Puncture wound without foreign body of right thumb without damage to nail, sequela','1997-03-11',151509,'DT109BZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
834,'Nondisplaced fracture of medial phalanx of right lesser toe(s), subsequent encounter for fracture with nonunion','2016-02-04',151507,'0SGB0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
835,'Unspecified displaced fracture of surgical neck of right humerus, subsequent encounter for fracture with nonunion','1990-01-05',151516,'07VJ4DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
836,'Displaced fracture of unspecified radial styloid process, initial encounter for open fracture type I or II','2007-08-13',151521,'2W0AX7Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
837,'Unspecified injury of right ankle, initial encounter','2007-02-17',151494,'0UW83JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
838,'Disorders of vestibular function','2007-01-29',151516,'09950ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
839,'Sprain of the superior tibiofibular joint and ligament, left knee, initial encounter','1996-10-11',151511,'0UB90ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
840,'Lead-induced chronic gout, left hand','1995-08-28',151488,'F0DZ1LZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
841,'Puncture wound without foreign body of lower back and pelvis without penetration into retroperitoneum, initial encounter','2010-02-23',151526,'0TWD03Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
842,'Stable burst fracture of fifth lumbar vertebra, subsequent encounter for fracture with nonunion','2013-05-22',151531,'0LR547Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
843,'Laceration of radial artery at wrist and hand level of unspecified arm, subsequent encounter','2015-05-19',151488,'0UJH3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
844,'Salter-Harris Type II physeal fracture of lower end of ulna, unspecified arm','2019-09-21',151494,'0P534ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
845,'Nondisplaced fracture of lateral condyle of unspecified tibia, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','2003-03-11',151508,'02BL0ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
846,'Sarcoidosis of other sites','2011-12-26',151493,'0Q9J0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
847,'Toxic effect of copper and its compounds, intentional self-harm, initial encounter','2010-03-19',151488,'0WWB4YZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
848,'Unspecified purulent endophthalmitis, left eye','2015-05-01',151484,'02HV3DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
849,'Burn of first degree of right forearm, initial encounter','2005-09-24',151491,'0DQQ8ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
850,'Pathological fracture in other disease, left ulna','2002-08-30',151505,'C25YYZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
851,'Juvenile rheumatoid arthritis with systemic onset, left knee','2019-07-24',151520,'099F7ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
852,'Poisoning by benzodiazepines, assault','1994-04-05',151511,'0RGA0JJ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
853,'Anterior subluxation of unspecified ulnohumeral joint, sequela','2013-09-09',151513,'0NS74ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
854,'Unspecified fracture of right femur, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with malunion','1994-03-30',151505,'B241ZZ3','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
855,'Other contact with alligator, sequela','1992-01-02',151516,'0WHN0YZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
856,'Crushing injury of left ring finger, subsequent encounter','2007-06-25',151485,'009K0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
857,'Pathological fracture, left foot, initial encounter for fracture','2003-12-22',151498,'039J3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
858,'Other injury of other specified muscles, fascia and tendons at thigh level, right thigh, subsequent encounter','2012-05-27',151524,'B51LZZA','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
859,'Other complications following immunization, not elsewhere classified, initial encounter','2003-03-07',151530,'0JUD07Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
860,'Nondisplaced fracture of body of hamate [unciform] bone, right wrist','2008-04-22',151493,'B3200ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
861,'Strain of muscle and tendon of back wall of thorax, initial encounter','2009-06-07',151487,'0GBF0ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
862,'Poisoning by oral contraceptives, accidental (unintentional), initial encounter','2009-02-24',151500,'04714EZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
863,'Hallux rigidus, unspecified foot','2009-05-22',151515,'080Q0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
864,'Zygomycosis','2000-08-15',151510,'DF016ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
865,'Other specified conditions associated with female genital organs and menstrual cycle','1997-11-09',151526,'0B9C4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
866,'Nondisplaced Zone II fracture of sacrum, sequela','2006-01-27',151515,'B53CZZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
867,'Lead-induced gout, hip','2002-01-17',151513,'0CRM0KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
868,'Displaced fracture of neck of scapula, unspecified shoulder, subsequent encounter for fracture with routine healing','2009-05-01',151501,'0U944ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
869,'Secondary parkinsonism','1990-01-14',151503,'04U43KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
870,'Poisoning by hydantoin derivatives, undetermined, subsequent encounter','2012-04-13',151530,'041J4JP','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
871,'Anisocoria','2017-02-20',151486,'0RGN44Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
872,'Pigmentary glaucoma, unspecified eye, moderate stage','2011-01-15',151500,'0WQ2XZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
873,'Melanoma in situ of left eyelid, including canthus','2009-06-12',151495,'0KUL0JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
874,'Anterior dislocation of left ulnohumeral joint','2019-12-19',151529,'0LBH4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
875,'Other specified diseases of anus and rectum','1993-08-17',151488,'0SG907Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
876,'Subluxation of tarsometatarsal joint of left foot, subsequent encounter','2004-06-22',151494,'037B4GZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
877,'Other physeal fracture of lower end of ulna, left arm, subsequent encounter for fracture with malunion','1993-04-05',151533,'0N983ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
878,'Idiopathic chronic gout, unspecified hand, without tophus (tophi)','2004-10-27',151487,'049M3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
879,'Other fracture of head and neck of unspecified femur, initial encounter for open fracture type I or II','1992-07-12',151521,'0QB33ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
880,'Bitten by other hoof stock, subsequent encounter','2004-07-11',151524,'00XF0ZN','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
881,'Fracture of unspecified part of right clavicle','2006-09-09',151533,'0NH045Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
882,'Unspecified traumatic displaced spondylolisthesis of seventh cervical vertebra, sequela','2000-12-08',151517,'D911B7Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
883,'Displaced fracture of unspecified tibial tuberosity','2016-01-19',151500,'05P3XMZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
884,'Complete traumatic amputation of scrotum and testis, subsequent encounter','2004-07-22',151528,'F0776UZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
885,'Other mechanical complication of implanted electronic neurostimulator of brain electrode (lead)','2016-03-03',151522,'00DL0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
886,'Maternal care for (suspected) damage to fetus from alcohol, fetus 2','2016-11-25',151513,'05RS0KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
887,'Unspecified injury of lesser saphenous vein at lower leg level, right leg, subsequent encounter','2000-02-02',151518,'0BN44ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
888,'Silent myocardial ischemia','1996-09-22',151516,'0YUR4JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
889,'Inferior dislocation of right acromioclavicular joint','1998-07-26',151488,'0CSC3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
890,'Other specified injury of left innominate or subclavian artery, subsequent encounter','2005-11-19',151504,'00XQ4ZF','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
891,'Displaced supracondylar fracture without intracondylar extension of lower end of right femur, initial encounter for open fracture type IIIA, IIIB, or IIIC','1996-07-25',151523,'0NPW40Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
892,'Disorders of visual pathways in (due to) neoplasm','2010-12-01',151513,'0M5K4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
893,'Driver of pick-up truck or van injured in collision with other nonmotor vehicle in nontraffic accident, sequela','1994-10-18',151511,'05HQ4DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
894,'Unspecified dislocation of right hip, subsequent encounter','2016-04-23',151500,'0RPN34Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
895,'Poisoning by emetics, accidental (unintentional), initial encounter','1991-03-23',151528,'0W110JJ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
896,'Other mechanical complication of carotid arterial graft (bypass), sequela','1999-12-09',151524,'0QT40ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
897,'Laceration of unspecified renal vein, initial encounter','2018-02-28',151487,'0QRH3JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
898,'Direct infection of left wrist in infectious and parasitic diseases classified elsewhere','1993-11-23',151509,'095P4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
899,'Other subluxation of unspecified knee','2010-06-17',151532,'0RSP45Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
900,'Toxic effects of zinc and its compounds','2000-11-20',151519,'0C0','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
901,'Other specified injury of unspecified innominate or subclavian artery','2006-11-23',151501,'05B54ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
902,'Rheumatoid polyneuropathy with rheumatoid arthritis of ankle and foot','2012-01-08',151521,'05994ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
903,'Pressure ulcer of left ankle','1997-03-17',151490,'0UUJXKZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
904,'Direct infection of right hip in infectious and parasitic diseases classified elsewhere','2011-11-06',151487,'0VLG4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
905,'Contact with power take-off devices (PTO), initial encounter','2006-08-25',151511,'03763EZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
906,'Parapoxvirus infections','2019-03-18',151501,'03C63ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
907,'Tear of articular cartilage of left knee, current','2014-03-17',151529,'0SWQ40Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
908,'Other specified injuries of unspecified part of neck, initial encounter','2017-05-21',151520,'0RH433Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
909,'Poisoning by beta-adrenoreceptor antagonists, undetermined','2003-03-23',151490,'0MTS4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
910,'Age-related osteoporosis with current pathological fracture, right humerus, sequela','2001-10-07',151529,'019800Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
911,'Fracture of unspecified shoulder girdle, part unspecified, subsequent encounter for fracture with delayed healing','1995-08-04',151509,'DP041ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
912,'Other fracture of shaft of femur','2014-05-06',151486,'0J040ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
913,'Newborn light for gestational age, 2000-2499 grams','2002-11-21',151526,'087X3DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
914,'Unspecified injury of left quadriceps muscle, fascia and tendon','2007-06-04',151495,'04RL4KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
915,'Changes in retinal vascular appearance, right eye','2001-01-15',151496,'0QBP3ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
916,'Unspecified injury to L4 level of lumbar spinal cord, initial encounter','2000-03-11',151511,'F14Z34Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
917,'Actinomycotic encephalitis','2004-07-24',151515,'0XQD0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
918,'Other specified injury of unspecified blood vessel at shoulder and upper arm level, right arm, sequela','2011-07-12',151492,'0U960ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
919,'Post-term pregnancy','1997-02-08',151505,'0JUJ0JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
920,'Other synovitis and tenosynovitis, upper arm','2014-10-03',151520,'0KNNXZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
921,'Puncture wound without foreign body of left buttock, subsequent encounter','2010-09-17',151491,'B52LYZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
922,'Traumatic hemorrhage of left cerebrum with loss of consciousness of unspecified duration, subsequent encounter','2010-11-10',151513,'0M9Q30Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
923,'Poisoning by, adverse effect of and underdosing of monoamine-oxidase-inhibitor antidepressants','1997-10-23',151498,'0U9770Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
924,'Toxic effect of venom of tarantula, accidental (unintentional), sequela','2013-03-24',151519,'0BPT70Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
925,'Obstructed labor due to breech presentation, fetus 4','2001-05-15',151503,'0FBC8ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
926,'Postprocedural intestinal obstruction','2018-04-18',151509,'0SC50ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
927,'Unspecified car occupant injured in collision with pedestrian or animal in traffic accident','2012-10-02',151500,'01WYX7Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
928,'Other secondary osteonecrosis, left shoulder','1999-08-18',151529,'0KU70KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
929,'Pathological fracture, left radius, sequela','2015-04-25',151516,'0RHU43Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
930,'Dislocation of L1/L2 lumbar vertebra','1999-02-04',151522,'0SGM0JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
931,'Salter-Harris Type III physeal fracture of upper end of radius, right arm','2007-02-02',151518,'0LB74ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
932,'Salter-Harris Type II physeal fracture of lower end of unspecified femur, subsequent encounter for fracture with routine healing','1992-03-19',151505,'BR39YZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
933,'Fistula, unspecified elbow','2007-02-14',151526,'0T1B4J9','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
934,'Acquired hemophilia','2003-07-30',151512,'0CU63KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
935,'Displaced fracture of neck of unspecified radius, subsequent encounter for open fracture type I or II with nonunion','2002-03-02',151489,'0QP93JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
936,'Urethral discharge without blood','2016-04-30',151485,'03NA3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
937,'Underdosing of anterior pituitary [adenohypophyseal] hormones','2010-07-08',151533,'02PA4NZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
938,'Supervision of pregnancy resulting from assisted reproductive technology, unspecified trimester','2012-05-04',151511,'019B4ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
939,'Unspecified superficial injury of left elbow','2014-06-26',151500,'B320Z2Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
940,'Laceration of unspecified blood vessel at forearm level','2014-08-11',151514,'01C93ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
941,'Fall on same level from slipping, tripping and stumbling with subsequent striking against sharp glass, initial encounter','2014-06-27',151493,'B827Y0Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
942,'Idiopathic chronic gout, unspecified ankle and foot, without tophus (tophi)','2009-09-17',151531,'0N9X0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
943,'Open bite of right middle finger with damage to nail, initial encounter','2012-09-11',151492,'0QW1XKZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
944,'Assault by unspecified explosive, sequela','1998-05-11',151495,'0SPD37Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
945,'Abrasion of right upper arm','2012-02-25',151498,'0TWBXDZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
946,'Dislocation of acromioclavicular joint, greater than 200% displacement','2003-11-14',151496,'0QH936Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
947,'Chloasma of right upper eyelid and periocular area','1997-11-16',151488,'03HB3DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
948,'Traumatic rupture of collateral ligament of right wrist, sequela','1998-12-28',151509,'0DH603Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
949,'Displaced fracture of lateral condyle of right humerus, subsequent encounter for fracture with routine healing','1997-02-21',151515,'03CD0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
950,'Corrosion of second degree of left thigh, subsequent encounter','2009-01-24',151526,'04CU4Z6','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
951,'Adverse effect of selective serotonin reuptake inhibitors','1991-12-31',151505,'0YBM4ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
952,'Puncture wound without foreign body of unspecified front wall of thorax without penetration into thoracic cavity','2002-08-24',151527,'07B14ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
953,'Toxic effect of 2-Propanol, undetermined, sequela','2010-04-09',151531,'0F9D0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
954,'Pressure ulcer of unspecified hip, stage 4','2006-05-02',151498,'061D0AY','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
955,'Other fracture of lower end of left femur, subsequent encounter for open fracture type I or II with malunion','2018-02-14',151523,'0QUR0JZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
956,'Burns involving 20-29% of body surface','2018-07-25',151506,'F07D1YZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
957,'Displaced transverse fracture of shaft of left radius, initial encounter for open fracture type IIIA, IIIB, or IIIC','2003-09-06',151508,'0XBF4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
958,'Military operations involving destruction of aircraft due to enemy fire or explosives, military personnel','2019-11-05',151505,'0Y6N0Z9','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
959,'Anaphylactic reaction due to serum','1995-01-29',151533,'03HF33Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
960,'External constriction of part of throat, sequela','2012-12-30',151497,'05580ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
961,'Nondisplaced osteochondral fracture of right patella, subsequent encounter for closed fracture with nonunion','1994-07-17',151506,'099A0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
962,'Abrasion of unspecified parts of thorax, subsequent encounter','2008-07-31',151510,'02H63DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
963,'Ligneous conjunctivitis, bilateral','2004-05-26',151530,'047W0F6','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
964,'Puncture wound with foreign body of left little finger with damage to nail','2019-07-11',151510,'02BX0ZX','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
965,'Other nondisplaced fracture of lower end of right humerus, subsequent encounter for fracture with malunion','2010-11-25',151515,'0SWBX8Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
966,'Displaced fracture of lateral cuneiform of right foot, subsequent encounter for fracture with routine healing','2007-12-14',151497,'0TWB33Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
967,'Breakdown (mechanical) of cardiac electrode, subsequent encounter','2013-07-03',151503,'0WU84KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
968,'Displaced transverse fracture of shaft of left tibia, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','1994-01-08',151515,'0P5K4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
969,'Other psychoactive substance dependence with other psychoactive substance-induced disorder','2007-09-02',151487,'0QBS3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
970,'Rheumatoid arthritis without rheumatoid factor, wrist','2001-04-07',151504,'05VA4DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
971,'Charcot''s joint, unspecified elbow','1990-06-11',151508,'0RPK07Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
972,'Continuing pregnancy after intrauterine death of one fetus or more, first trimester, fetus 1','2012-10-21',151515,'06190AY','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
973,'Breakdown (mechanical) of surgically created arteriovenous fistula, sequela','1998-09-27',151508,'0JHK3NZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
974,'Urethral diverticulum','2007-08-22',151524,'047N0G6','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
975,'Separation of retinal layers','2018-11-05',151515,'D010BBZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
976,'Vitreomacular adhesion, unspecified eye','2013-10-13',151511,'0VJS3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
977,'Atrophy of bilateral orbit','1993-05-09',151527,'0QBG3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
978,'Poisoning by cannabis (derivatives), accidental (unintentional), initial encounter','1992-04-24',151494,'0RPM03Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
979,'Pedestrian on foot injured in collision with car, pick-up truck or van in traffic accident, initial encounter','1999-01-14',151515,'05P30MZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
980,'Arthropathies in other specified diseases classified elsewhere, unspecified shoulder','1991-08-18',151510,'0PBP4ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
981,'Unspecified fracture of shaft of right femur, initial encounter for open fracture type IIIA, IIIB, or IIIC','1991-02-04',151525,'CW5JDZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
982,'Other specified arthritis, other site','2013-04-21',151486,'0B113Z4','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
983,'Partial traumatic amputation of right shoulder and upper arm, level unspecified, subsequent encounter','1995-09-29',151504,'30230T1','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
984,'Chorioamnionitis, first trimester, fetus 5','2011-08-24',151508,'BB291ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
985,'Crushing injury of right hand, sequela','2003-03-04',151518,'B30NZZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
986,'Unspecified physeal fracture of phalanx of right toe, subsequent encounter for fracture with routine healing','2003-06-20',151495,'05U047Z','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
987,'Infection and inflammatory reaction due to internal fixation device of left ulna','2002-02-20',151506,'CW23YZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
988,'Other chronic hematogenous osteomyelitis, right radius and ulna','2000-08-19',151515,'0U957ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
989,'Laceration of intrinsic muscle, fascia and tendon of other finger at wrist and hand level, initial encounter','1993-07-08',151495,'30240Y2','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
990,'Stiffness of left wrist, not elsewhere classified','2014-11-08',151523,'0J8S3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
991,'Laceration without foreign body of unspecified elbow, sequela','2017-03-30',151510,'039T0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
992,'Toxic effect of contact with stingray, intentional self-harm, initial encounter','1992-07-20',151500,'0B5L7ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
993,'Graft-versus-host disease, unspecified','2004-06-30',151499,'06NQ0ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
994,'Fibrosis due to other internal prosthetic devices, implants and grafts, initial encounter','2013-10-20',151524,'DF032ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
995,'Nondisplaced fracture of medial cuneiform of left foot, initial encounter for closed fracture','1997-09-30',151506,'0JQ40ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
996,'Displaced articular fracture of head of left femur, sequela','2018-10-03',151509,'03120AK','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
997,'Displaced spiral fracture of shaft of radius, right arm, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion','2010-11-25',151506,'095F3ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
998,'Bedroom in school dormitory as the place of occurrence of the external cause','2010-10-13',151532,'0B787DZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
999,'Pedestrian on other flat-bottomed pedestrian conveyance colliding with stationary object, sequela','1998-05-13',151497,'0Y0K4KZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
1000,'Displaced fracture of base of neck of right femur, subsequent encounter for open fracture type I or II with malunion','1995-05-06',151518,'02714ZZ','postgres','2017-09-11 10:02:43.725','postgres','2017-09-11 10:02:43.725');
INSERT INTO campanias.atencion (codigo,observacion,fecha_atencion,persona,observacion_internacion,usr_create,time_create,usr_update,time_update) VALUES (
1001,'Primera atencion','2017-09-09',234729,NULL,'','2017-09-12 09:24:34.976','','2017-09-12 09:24:34.976');
