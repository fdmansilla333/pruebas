﻿INSERT INTO campanias.habito (codigo,atencion,tipo_habito,observacion,cantidad,usr_create,time_create,usr_update,time_update) VALUES (
1,1,1,'cigarrillos por dia',10,'postgres','2017-09-11 10:18:46.870','postgres','2017-09-11 10:18:46.870');
INSERT INTO campanias.habito (codigo,atencion,tipo_habito,observacion,cantidad,usr_create,time_create,usr_update,time_update) VALUES (
2,1,2,'Litros por semana',1,'postgres','2017-09-11 10:18:46.870','postgres','2017-09-11 10:18:46.870');
INSERT INTO campanias.habito (codigo,atencion,tipo_habito,observacion,cantidad,usr_create,time_create,usr_update,time_update) VALUES (
3,1,3,'minutos por dia',45,'postgres','2017-09-11 10:18:46.870','postgres','2017-09-11 10:18:46.870');
