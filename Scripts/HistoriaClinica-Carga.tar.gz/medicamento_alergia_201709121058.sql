﻿INSERT INTO campanias.medicamento_alergia (codigo,atencion,descripcion,producto,usr_create,time_create,usr_update,time_update) VALUES (
1,1,'Penicilina',22333,'postgres','2017-09-11 10:38:17.883','postgres','2017-09-11 10:38:17.883');
INSERT INTO campanias.medicamento_alergia (codigo,atencion,descripcion,producto,usr_create,time_create,usr_update,time_update) VALUES (
2,1,'Novalgina',44221,'postgres','2017-09-11 10:38:18.743','postgres','2017-09-11 10:38:18.743');
