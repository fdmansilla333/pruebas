﻿INSERT INTO campanias.medicamento_consume (codigo,medicamentos_principio_activo,presentacion,dosificacion,producto,atencion,usr_create,time_create,usr_update,time_update) VALUES (
1,'Ibuprofeno','400 mg iny.x 50 x 3 ml  ','1',6988,1,'postgres','2017-09-11 10:32:16.404','postgres','2017-09-11 10:32:16.404');
INSERT INTO campanias.medicamento_consume (codigo,medicamentos_principio_activo,presentacion,dosificacion,producto,atencion,usr_create,time_create,usr_update,time_update) VALUES (
2,'Benadryl','caps.x 25','1 por dia',7679,1,'postgres','2017-09-11 10:32:16.633','postgres','2017-09-11 10:32:16.633');
INSERT INTO campanias.medicamento_consume (codigo,medicamentos_principio_activo,presentacion,dosificacion,producto,atencion,usr_create,time_create,usr_update,time_update) VALUES (
3,'Bayaspirina','comp x 20','1 por dia',2793,1,'postgres','2017-09-11 10:32:16.649','postgres','2017-09-11 10:32:16.649');
