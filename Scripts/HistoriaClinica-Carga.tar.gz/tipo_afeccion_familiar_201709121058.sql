﻿INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
1,'Hipertension Arterial','HTA','fdmansilla','2017-09-11 09:47:52.076','fdmansilla','2017-09-11 09:47:52.076');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
2,'Cardiopatia','Cardiopatia','postgres','2017-09-11 09:52:01.042','postgres','2017-09-11 09:52:01.042');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
3,'Diabetes','DBT','postgres','2017-09-11 09:52:01.062','postgres','2017-09-11 09:52:01.062');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
4,'Accidente cardiovascular / Infarto Agudo de Miocardio','ACV/IAM','postgres','2017-09-11 09:52:01.069','postgres','2017-09-11 09:52:01.069');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
5,'Cáncer de Colon','Cancer de colon','postgres','2017-09-11 09:52:01.077','postgres','2017-09-11 09:52:01.077');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
6,'Cáncer de mama','Cancer de mama','postgres','2017-09-11 09:52:01.085','postgres','2017-09-11 09:52:01.085');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
7,'Otras enfermedades oncologicas','Otras enfermedades oncologicas','postgres','2017-09-11 09:52:01.094','postgres','2017-09-11 09:52:01.094');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
8,'Consumo de drogas','Consumo de drogas','postgres','2017-09-11 09:52:01.125','postgres','2017-09-11 09:52:01.125');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
9,'Abuso de alcohol','Abuso de Alcohol','postgres','2017-09-11 09:52:01.135','postgres','2017-09-11 09:52:01.135');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
10,'Depresión','Depresion','postgres','2017-09-11 09:52:01.143','postgres','2017-09-11 09:52:01.143');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
11,'Maltrato o violencia familiar','Maltrato o violencia familiar','postgres','2017-09-11 09:52:01.152','postgres','2017-09-11 09:52:01.152');
INSERT INTO campanias.tipo_afeccion_familiar (codigo,descripcion,nombre,usr_create,time_create,usr_update,time_update) VALUES (
12,'Otras','Otras','postgres','2017-09-11 09:52:01.160','postgres','2017-09-11 09:52:01.160');
