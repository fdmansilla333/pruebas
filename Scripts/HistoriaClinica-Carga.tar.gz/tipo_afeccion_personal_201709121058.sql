﻿INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
1,'HTA','Hipertensión arterial','postgres','2017-09-11 09:59:27.870','postgres','2017-09-11 09:59:27.870');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
2,'DBT','Diabetes','postgres','2017-09-11 09:59:27.887','postgres','2017-09-11 09:59:27.887');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
3,'Enfermedad coronaria','Enfermedad coronaria','postgres','2017-09-11 09:59:27.895','postgres','2017-09-11 09:59:27.895');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
4,'IAM','Infarto Agudo de Miocardio','postgres','2017-09-11 09:59:27.903','postgres','2017-09-11 09:59:27.903');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
5,'ACV','Accidente Cardiovascular','postgres','2017-09-11 09:59:27.912','postgres','2017-09-11 09:59:27.912');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
6,'Epoc/asma','Epoc/Asma','postgres','2017-09-11 09:59:27.920','postgres','2017-09-11 09:59:27.920');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
7,'Alergia/Atopia','Alergia/Atopia','postgres','2017-09-11 09:59:27.928','postgres','2017-09-11 09:59:27.928');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
8,'Enfermedad reumatica','Enfermedad reumática','postgres','2017-09-11 09:59:27.936','postgres','2017-09-11 09:59:27.936');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
9,'Enfermedad oncologica','Enfermedad oncologica','postgres','2017-09-11 09:59:27.945','postgres','2017-09-11 09:59:27.945');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
10,'TBC','Tuberculosis','postgres','2017-09-11 09:59:27.953','postgres','2017-09-11 09:59:27.953');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
11,'Chagas','Chagas','postgres','2017-09-11 09:59:27.962','postgres','2017-09-11 09:59:27.962');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
12,'ITS','Enfermedades de transmisión sexual','postgres','2017-09-11 09:59:27.970','postgres','2017-09-11 09:59:27.970');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
13,'Psicopatologicos','Psicopatológicos','postgres','2017-09-11 09:59:27.978','postgres','2017-09-11 09:59:27.978');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
14,'Neurologicos','Neurologicos','postgres','2017-09-11 09:59:27.987','postgres','2017-09-11 09:59:27.987');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
15,'Maltrato / Violencia familiar','Maltrato / Violencia familiar','postgres','2017-09-11 09:59:27.995','postgres','2017-09-11 09:59:27.995');
INSERT INTO campanias.tipo_afeccion_personal (codigo,nombre,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
16,'Otros','Otros','postgres','2017-09-11 09:59:28.004','postgres','2017-09-11 09:59:28.004');
