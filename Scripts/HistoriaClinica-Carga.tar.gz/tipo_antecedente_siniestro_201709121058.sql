﻿INSERT INTO campanias.tipo_antecedente_siniestro (codigo,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
1,'Internaciones','postgres','2017-09-11 10:00:09.874','postgres','2017-09-11 10:00:09.874');
INSERT INTO campanias.tipo_antecedente_siniestro (codigo,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
2,'Operaciones','postgres','2017-09-11 10:00:09.889','postgres','2017-09-11 10:00:09.889');
INSERT INTO campanias.tipo_antecedente_siniestro (codigo,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
3,'Accidentes','postgres','2017-09-11 10:00:09.897','postgres','2017-09-11 10:00:09.897');
