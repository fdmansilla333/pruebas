﻿INSERT INTO campanias.tipo_habito (codigo,nombre_corto,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
1,'Fuma','Fuma','postgres','2017-09-11 10:01:20.374','postgres','2017-09-11 10:01:20.374');
INSERT INTO campanias.tipo_habito (codigo,nombre_corto,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
2,'Alcohol','Alcohol','postgres','2017-09-11 10:01:20.402','postgres','2017-09-11 10:01:20.402');
INSERT INTO campanias.tipo_habito (codigo,nombre_corto,descripcion,usr_create,time_create,usr_update,time_update) VALUES (
3,'Actividad fisica','Actividad fisica','postgres','2017-09-11 10:01:20.417','postgres','2017-09-11 10:01:20.417');
